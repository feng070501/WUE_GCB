# -*- coding: utf-8 -*-
"""
Created on Wed Apr 24 10:23:49 2024

@author: LF
"""
'''本程序用于对数据按干旱过程进行分组。'''
#注意更改IGBP
import os
import re
import glob 
import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%分IGBP
dir_list = glob.glob(r'F:/phd1/V10/SHR/*/06WUE/')
dfs = []
for dd in dir_list:
    dd = dd.replace('\\', '/')
    substrings = re.split(r'/', dd)  # 按/分割
    igbp = substrings[3]
    siteid = substrings[4]        
    csvpath1 = os.path.join(dd, 'ewue_zscflt.csv')
    ewue_frame = pd.read_csv(csvpath1, index_col=0, parse_dates=True, header=0)
    csvpath2 = os.path.join(dd, 'twue_zscflt.csv')
    twue_frame = pd.read_csv(csvpath2, index_col=0, parse_dates=True, header=0)
    csvpath3 = os.path.join(dd, 'iwue_zscflt.csv')
    iwue_frame = pd.read_csv(csvpath3, index_col=0, parse_dates=True, header=0)
    csvpath4 = 'F:/phd1/V10/'+igbp+'/'+siteid+'/03data_flt/data_zscflt.csv'
    ori_frame = pd.read_csv(csvpath4, index_col=0, parse_dates=True, header=0)
    et_frame = ori_frame['et'].to_frame()
    gpp_frame = ori_frame['gpp'].to_frame()
    t_frame = ori_frame['t'].to_frame()
    csvpath5 = 'F:/phd1/V10/'+igbp+'/'+siteid+'/05SMDI/spei_smdi.csv'
    spei_smdi = pd.read_csv(csvpath5, index_col=0, parse_dates=True, header=0)
    di_frame = pd.DataFrame(spei_smdi["DI"])
    csvpath6 = 'F:/phd1/V10/'+igbp+'/'+siteid+'/06WUE/gc_zscflt.csv'
    gc_frame = pd.read_csv(csvpath6, index_col=0, parse_dates=True, header=0)    
    common_df1 = pd.merge(di_frame, et_frame, how='inner', left_index=True, right_index=True) #取交集合并各dataframe
    common_df2 = pd.merge(common_df1, t_frame, how='inner', left_index=True, right_index=True)
    common_df3 = pd.merge(common_df2, gpp_frame, how='inner', left_index=True, right_index=True)
    common_df4 = pd.merge(common_df3, gc_frame, how='inner', left_index=True, right_index=True)
    common_df5 = pd.merge(common_df4, ewue_frame, how='inner', left_index=True, right_index=True)
    common_df6 = pd.merge(common_df5, twue_frame, how='inner', left_index=True, right_index=True)
    common_df = pd.merge(common_df6, iwue_frame, how='inner', left_index=True, right_index=True)
    common_df.dropna(inplace=True) #删除nan位置所在的元素
    dfs.append(common_df)
    print(siteid)
combined_df = pd.concat(dfs, axis=0) # 使用pd.concat函数进行上下合并
combined_df.reset_index(drop=True, inplace=True)   # 重置索引（可选），以使合并后的DataFrame有连续的索引      
grouped = combined_df.groupby('DI') # 使用groupby函数按第一列分组    
for group_name, group_data in grouped: # 遍历每个组并输出对应的样本
    group_data.to_csv('F:/phd1/V10/'+igbp+'/01multisite/02group/group'+str(int(group_name))+'.csv', index=True, header=True, float_format='%.4f')
        
#%%全站点
dir_list = glob.glob(r'F:/phd1/V10/*/*/06WUE/')
dfs = []
for dd in dir_list:
    dd = dd.replace('\\', '/')
    substrings = re.split(r'/', dd)  # 按/分割
    igbp = substrings[3]
    siteid = substrings[4]        
    csvpath1 = os.path.join(dd, 'ewue_zscflt.csv')
    ewue_frame = pd.read_csv(csvpath1, index_col=0, parse_dates=True, header=0)
    csvpath2 = os.path.join(dd, 'twue_zscflt.csv')
    twue_frame = pd.read_csv(csvpath2, index_col=0, parse_dates=True, header=0)
    csvpath3 = os.path.join(dd, 'iwue_zscflt.csv')
    iwue_frame = pd.read_csv(csvpath3, index_col=0, parse_dates=True, header=0)
    csvpath4 = 'F:/phd1/V10/'+igbp+'/'+siteid+'/03data_flt/data_zscflt.csv'
    ori_frame = pd.read_csv(csvpath4, index_col=0, parse_dates=True, header=0)
    et_frame = ori_frame['et'].to_frame()
    gpp_frame = ori_frame['gpp'].to_frame()
    t_frame = ori_frame['t'].to_frame()
    csvpath5 = 'F:/phd1/V10/'+igbp+'/'+siteid+'/05SMDI/spei_smdi.csv'
    spei_smdi = pd.read_csv(csvpath5, index_col=0, parse_dates=True, header=0)
    di_frame = pd.DataFrame(spei_smdi["DI"])
    csvpath6 = 'F:/phd1/V10/'+igbp+'/'+siteid+'/06WUE/gc_zscflt.csv'
    gc_frame = pd.read_csv(csvpath6, index_col=0, parse_dates=True, header=0)
    
    common_df1 = pd.merge(di_frame, et_frame, how='inner', left_index=True, right_index=True) #取交集合并各dataframe
    common_df2 = pd.merge(common_df1, t_frame, how='inner', left_index=True, right_index=True)
    common_df3 = pd.merge(common_df2, gpp_frame, how='inner', left_index=True, right_index=True)
    common_df4 = pd.merge(common_df3, gc_frame, how='inner', left_index=True, right_index=True)
    common_df5 = pd.merge(common_df4, ewue_frame, how='inner', left_index=True, right_index=True)
    common_df6 = pd.merge(common_df5, twue_frame, how='inner', left_index=True, right_index=True)
    common_df = pd.merge(common_df6, iwue_frame, how='inner', left_index=True, right_index=True)
    common_df.dropna(inplace=True) #删除nan位置所在的元素
    dfs.append(common_df)
    print(siteid)
combined_df = pd.concat(dfs, axis=0) # 使用pd.concat函数进行上下合并
combined_df.reset_index(drop=True, inplace=True)   # 重置索引（可选），以使合并后的DataFrame有连续的索引      
grouped = combined_df.groupby('DI') # 使用groupby函数按第一列分组    
for group_name, group_data in grouped: # 遍历每个组并输出对应的样本
    group_data.to_csv('F:/phd1/V10/01allsite/04group/group'+str(int(group_name))+'.csv', index=True, header=True, float_format='%.4f')

# -*- coding: utf-8 -*-
"""
Created on Wed Jul 10 17:41:24 2024

@author: LF
"""
'''本程序用于计算EWUE、TWUE和IWUE'''
#注意更改IGBP
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import warnings
import glob
import re
import os
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%计算WUE和iWUE
#########计算全部的WUE
dir_list = glob.glob(r'F:/phd1/V7/*/*/01data_dd/data_ori.csv')
for dd in dir_list:
    dd = dd.replace('\\', '/')
    substrings = re.split(r'/', dd)  # 按/分割
    igbp = substrings[3]
    siteid = substrings[4]    
    ori = pd.read_csv(dd, index_col=0, parse_dates=True, header=0)
    et = ori.et.values
    gpp = ori.gpp.values
    t = ori['t'].values
    csvpath3 = 'F:/phd1/V7/'+igbp+'/'+siteid+'/06WUE/gc_ori.csv'
    gc = pd.read_csv(csvpath3, index_col=0, parse_dates=True, header=0).values.flatten()
    ewue = gpp/et    #(gC·kg-1 H2O)
    ewue_df = pd.DataFrame(ewue, index = ori.index, columns = ['EWUE'])    
    ewue_df.replace([np.inf, -np.inf], np.nan, inplace=True)
    ewue_df.loc[ewue_df['EWUE'] > 20, 'EWUE'] = np.nan
    ewue_df.to_csv('F:/phd1/V7/'+igbp+'/'+siteid+'/06WUE/ewue_ori.csv', float_format='%.4f')
    twue = gpp/t    #(gC·kg-1 H2O)
    twue_df = pd.DataFrame(twue, index = ori.index, columns = ['TWUE'])    
    twue_df.replace([np.inf, -np.inf], np.nan, inplace=True)
    twue_df.loc[twue_df['TWUE'] > 20, 'TWUE'] = np.nan
    twue_df.to_csv('F:/phd1/V7/'+igbp+'/'+siteid+'/06WUE/twue_ori.csv', float_format='%.4f')    
    iwue = gpp/gc    #(gC·kg-1 H2O)
    iwue_df = pd.DataFrame(iwue, index = ori.index, columns = ['IWUE'])    
    iwue_df.replace([np.inf, -np.inf], np.nan, inplace=True)
    iwue_df.loc[iwue_df['IWUE'] > 150, 'IWUE'] = np.nan
    iwue_df.to_csv('F:/phd1/V7/'+igbp+'/'+siteid+'/06WUE/iwue_ori.csv', float_format='%.4f')
    #绘图
    parameters = {'axes.labelsize': 30,
              'axes.titlesize': 30,
              'xtick.labelsize': 30,
              'ytick.labelsize': 30,
              'figure.dpi': 300,
              'lines.linewidth': 4,
              'font.family': 'Arial'}
    plt.rcParams.update(parameters)    
    fig, axs = plt.subplots(3, 1, figsize=(22, 12), dpi=300)
    index1 = ori.index
    axs[0].scatter(index1, ewue, color='#82b4d1')
    axs[0].set_title(f'(a) {siteid} EWUE')
    axs[0].set_ylabel('gC·kg-1 H2O', fontsize=30,y=0.8)  # 设置y轴刻度标签
    axs[1].scatter(index1, twue, color='#82b4d1')
    axs[1].set_title(f'(b) {siteid} TWUE')
    axs[1].set_ylabel('gC·kg-1 H2O', fontsize=30,y=0.8)  # 设置y轴刻度标签
    axs[2].scatter(index1, iwue, color='#e0b7b7')
    axs[2].set_title(f'(c) {siteid} IWUE')
    axs[2].set_ylabel('gC/mol', fontsize=30, y=0.8)  # 设置y轴刻度标签
    for i in range(2):
        axs[i].spines['top'].set_linewidth(2)  # 设置顶部边框粗细为2
        axs[i].spines['bottom'].set_linewidth(2)  # 设置底部边框粗细为2
        axs[i].spines["right"].set_color(None)# 去掉右边框
        axs[i].spines["top"].set_color(None)# 去掉上边框
        axs[i].grid(True,axis='y',c='lightgray',ls='--') #设置网格线        
    plt.tight_layout()
    plt.show()
    print(siteid)
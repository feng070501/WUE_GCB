# -*- coding: utf-8 -*-
"""
Created on Tue Sep 24 21:37:05 2024

@author: LF
"""
'''本程序将干旱指数当做轴，计算干旱指数划分的格子内WUE的均值绘制热力图。'''
###############所有站点与分igbp站点多处手动修改运行
import os
import re
import glob 
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%
dir_list = glob.glob(r'F:/phd1/V10/*/*/04SPEI/')
info_path = 'F:/phd1/V10/01allsite/02drought/SPEI_scale.xlsx'
site_frame = pd.read_excel(info_path, index_col=0, header=0)
dfs = []
for dd in dir_list:
    dd = dd.replace('\\', '/')
    substrings = re.split(r'/', dd)  # 按/分割
    igbp = substrings[3]
    siteid = substrings[4]
    scale = site_frame.loc[site_frame['siteid'] == siteid, 'SPEI_scale'].values[0]        
    csvpath1 = 'F:/phd1/V10/'+igbp+'/'+siteid+'/04SPEI/SPEI'+str(scale*30)+'.csv'
    spei = pd.read_csv(csvpath1, index_col=0, parse_dates=True, header=0)
    csvpath2 = 'F:/phd1/V10/'+igbp+'/'+siteid+'/05SMDI/SMDI30.csv'
    smdi = pd.read_csv(csvpath2, index_col=0, parse_dates=True, header=0)
    csvpath3 = 'F:/phd1/V10/'+igbp+'/'+siteid+'/06WUE/ewue_zscflt.csv'
    ewue_frame = pd.read_csv(csvpath3, index_col=0, parse_dates=True, header=0)
    csvpath4 = 'F:/phd1/V10/'+igbp+'/'+siteid+'/06WUE/twue_zscflt.csv'
    twue_frame = pd.read_csv(csvpath4, index_col=0, parse_dates=True, header=0)
    csvpath4 = 'F:/phd1/V10/'+igbp+'/'+siteid+'/06WUE/iwue_zscflt.csv'
    iwue_frame = pd.read_csv(csvpath4, index_col=0, parse_dates=True, header=0)
    common_df1 = pd.merge(spei, smdi, how='inner', left_index=True, right_index=True)
    common_df2 = pd.merge(common_df1, ewue_frame, how='inner', left_index=True, right_index=True)
    common_df3 = pd.merge(common_df2, twue_frame, how='inner', left_index=True, right_index=True)
    common_df = pd.merge(common_df3, iwue_frame, how='inner', left_index=True, right_index=True)
    common_df.dropna(inplace=True) #删除nan位置所在的元素
    dfs.append(common_df)
    print(siteid)
combined_df = pd.concat(dfs, axis=0) # 使用pd.concat函数进行上下合并
combined_df.reset_index(drop=True, inplace=True)   # 重置索引（可选），以使合并后的DataFrame有连续的索引
# 根据百分位数将第1列和第2列分成10段
combined_df['SPEI_bin'] = pd.qcut(combined_df['SPEI'], 10, labels=False)
combined_df['SMDI_bin'] = pd.qcut(combined_df['SMDI'], 10, labels=False)
# 计算每个格子里第3列的均值，做数据透视表
heatmap_ewue = combined_df.pivot_table(values='EWUE', index='SMDI_bin', columns='SPEI_bin', aggfunc='mean')
heatmap_ewue.columns = list(range(10, 101, 10))
heatmap_ewue.index = list(range(10, 101, 10))
heatmap_twue = combined_df.pivot_table(values='TWUE', index='SMDI_bin', columns='SPEI_bin', aggfunc='mean')
heatmap_twue.columns = list(range(10, 101, 10))
heatmap_twue.index = list(range(10, 101, 10))
heatmap_iwue = combined_df.pivot_table(values='IWUE', index='SMDI_bin', columns='SPEI_bin', aggfunc='mean')
heatmap_iwue.columns = list(range(10, 101, 10))
heatmap_iwue.index = list(range(10, 101, 10))
#%%创建一个新的颜色映射
mycmap = LinearSegmentedColormap.from_list('fe7', ['#25834d', '#f4f3ba', '#892a6e'], N=100)
parameters = {'axes.labelsize': 40,
          'axes.titlesize': 45,
          'xtick.labelsize': 40,
          'ytick.labelsize': 40,
          'figure.dpi': 300,
          'lines.linewidth': 3,
          'font.family': 'Arial',
          'axes.titlepad': 20}
plt.rcParams.update(parameters)
fig, axes = plt.subplots(1, 3, figsize=(38, 15))#横版
#fig, axes = plt.subplots(3, 1, figsize=(15, 30)) #竖版
# 为 colorbar 留出空间
fig.subplots_adjust(right=1)  # 调整右边距，腾出空间
cbar_ax = fig.add_axes([1.02, 0.15, 0.02, 0.7])  # [左, 下, 宽, 高]（0‑1 之间）

# 第一个热力图，绘制 colorbar
sns.heatmap(
    heatmap_ewue[::-1],
    cmap=mycmap, annot=True, fmt=".2f",
    ax=axes[0], annot_kws={"size": 30},
    vmin=-0.3, vmax=0.3,
    cbar=True, cbar_ax=cbar_ax, cbar_kws={'extend': 'both'}
)
axes[0].set_title('EWUE')
axes[0].set_ylabel('SMDI', labelpad=10)
axes[0].set_xlabel('SPEI', labelpad=10)

# 其余两个热力图，不绘制 colorbar，但共用 cbar_ax
for ax, data, title in zip(axes[1:], 
                           [heatmap_twue[::-1], heatmap_iwue[::-1]],
                           ['TWUE', 'IWUE']):
    sns.heatmap(
        data,
        cmap=mycmap, annot=True, fmt=".2f",
        ax=ax, annot_kws={"size": 30},
        vmin=-0.3, vmax=0.3,
        cbar=False, cbar_ax=cbar_ax  # 不绘 colorbar
    )
    ax.set_title(title)
    ax.set_xlabel('SPEI', labelpad=10)
#axes[2].set_xlabel('SPEI', labelpad=10)
plt.tight_layout()
plt.show()
#os.makedirs('F:/phd1/V10/DBF/01multisite/01stat', exist_ok=True)  #创建站点文件夹
fig.savefig('F:/phd1/V10/01allsite/05stat/DI-WUE.jpg',dpi=300,bbox_inches = 'tight')

# -*- coding: utf-8 -*-
"""
Created on Fri Sep 27 14:49:52 2024

@author: LF
"""
'''本程序用于绘制各站点转变点的箱线图。'''
#注意更改多处IGBP
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.markers import MarkerStyle
import numpy as np
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%
csvpath = 'F:/phd1/V10/SHR/01multisite/04amc/tp_point.csv'
df = pd.read_csv(csvpath, index_col=0, header=0)
#df = df.drop(columns='siteid')
#%%
# 设置参数
plt.rcParams.update({
    'font.family': 'Arial',
    'axes.labelsize': 25,
    'axes.titlesize': 25,
    'xtick.labelsize': 20,
    'ytick.labelsize': 20,
    'figure.dpi': 300,
    'lines.linewidth': 3
})
# 创建绘图
fig, ax = plt.subplots(figsize=(12,6))
# 添加背景颜色
back_colors = ['#FADADD', '#B5EAD7', '#FFFACD', '#9ACDDB']  # 设置每组列的背景颜色
for i in range(4):
    ax.axvspan(i*2-0.5, i*2+1.5, facecolor=back_colors[i], alpha=0.3)
# 使用 melt 转换数据格式
df_long = df.melt(var_name='Variable', value_name='Value')
# 直接从新列名中提取分组信息（后缀部分），添加 group 列
df_long['group'] = df_long['Variable'].apply(lambda x: x.split('_')[1])

sns.boxplot(
    data=df_long,
    x="Variable",
    y="Value",
    hue="group",
    dodge=False,
    palette=['#3a88c8', '#a22e45'],
    linewidth=1.5,
    width=0.6,
    showfliers=False,
    boxprops=dict(edgecolor='black'),
    medianprops=dict(color='white', linewidth=2),
    whiskerprops=dict(linewidth=1.5),
    capprops=dict(linewidth=1.5),
    ax=ax
)
# —— 移除 seaborn 自动添加的第二个 legend —— #
if ax.get_legend() is not None:
    ax.legend_.remove()
# 设置坐标轴
ax.set_xlabel('')
ax.set_xticklabels(['SPEI','SMDI']*4)
ax.set_ylabel('Drought Thresholds')

# 添加分组标签
for i, text in enumerate(['Gc','GPP','ET','T']):
    ax.text(i*2+0.5, 1.02, text, transform=ax.get_xaxis_transform(), ha='center', fontsize=25)
plt.tight_layout()
plt.savefig('F:/phd1/V10/SHR/01multisite/04amc/tp_point.jpg', dpi=300, bbox_inches='tight')
plt.show()
#%%


# -*- coding: utf-8 -*-
"""
Created on Fri Sep 27 14:49:52 2024

@author: LF
"""
'''本程序用于绘制各站点转变点的箱线图。'''
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.markers import MarkerStyle
import numpy as np
import seaborn as sns
import re
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%
csvpath1 = 'F:/phd1/V10/01allsite/07amc/GPP_tpoint.csv'
gpp_tpoint = pd.read_csv(csvpath1, index_col=0, parse_dates=True, header=0)
substrings = re.split(r'/', csvpath1)  # 按/分割
igbp = substrings[3]
csvpath2 = 'F:/phd1/V10/01allsite/07amc/ET_tpoint.csv'
et_tpoint = pd.read_csv(csvpath2, index_col=0, parse_dates=True, header=0)
csvpath3 = 'F:/phd1/V10/01allsite/07amc/T_tpoint.csv'
t_tpoint = pd.read_csv(csvpath3, index_col=0, parse_dates=True, header=0)
csvpath4 = 'F:/phd1/V10/01allsite/07amc/Gc_tpoint.csv'
gc_tpoint = pd.read_csv(csvpath4, index_col=0, parse_dates=True, header=0)
gc_tpoint.index = gpp_tpoint.index = t_tpoint.index = et_tpoint.index = list(range(len(gpp_tpoint)))
df = pd.concat([gc_tpoint, gpp_tpoint, et_tpoint, t_tpoint], axis=1)  # 合并这三个DataFrame
df = df.drop(columns='siteid')

#%%
# 设置参数
plt.rcParams.update({
    'font.family': 'Arial',
    'axes.labelsize': 25,
    'axes.titlesize': 25,
    'xtick.labelsize': 20,
    'ytick.labelsize': 20,
    'figure.dpi': 300,
    'lines.linewidth': 3
})
# 创建绘图
fig, ax = plt.subplots(figsize=(12,6))
# 添加背景颜色
back_colors = ['#FADADD', '#B5EAD7', '#FFFACD', '#9ACDDB']  # 设置每组列的背景颜色
for i in range(4):
    ax.axvspan(i*2-0.5, i*2+1.5, facecolor=back_colors[i], alpha=0.3)
# 定义分组映射：根据原列的索引
group_mapping = {0: 'Gc', 1: 'Gc', 2: 'GPP', 3: 'GPP', 4: 'ET', 5: 'ET', 6: 'T', 7: 'T'}
# 为了区分重复的列名，给每一列添加后缀（例如 'SPEI' 变为 'SPEI_Gc'）
df.columns = [f"{col}_{group_mapping[i]}" for i, col in enumerate(df.columns)]
# 使用 melt 转换数据格式
df_long = df.melt(var_name='Variable', value_name='Value')
# 直接从新列名中提取分组信息（后缀部分），添加 group 列
df_long['group'] = df_long['Variable'].apply(lambda x: x.split('_')[0])

sns.boxenplot(
    data=df_long,
    x="Variable",
    y="Value",
    hue="group",
    dodge=False,                   # 分组错位
    palette=['#3a88c8','#a22e45'],
    linewidth=1.5,                # 轮廓线宽度
    saturation=0.8,              # 填充饱和度
    showfliers=False,             # 隐藏离群点
    width=0.5,       #箱体宽度
    linecolor = 'black',
    ax=ax
)
# —— 移除 seaborn 自动添加的第二个 legend —— #
if ax.get_legend() is not None:
    ax.legend_.remove()
# 设置坐标轴
ax.set_xlabel('')
ax.set_xticklabels(['SPEI','SMDI']*4)
ax.set_ylabel('Drought Thresholds')

# 添加分组标签
for i, text in enumerate(['Gc','GPP','ET','T']):
    ax.text(i*2+0.5, 1.02, text, transform=ax.get_xaxis_transform(), ha='center', fontsize=25)
plt.tight_layout()
plt.savefig('F:/phd1/V10/01allsite/07amc/tp_point.jpg', dpi=300, bbox_inches='tight')
plt.show()
#%%

# -*- coding: utf-8 -*-
"""
Created on Fri Jul 26 10:14:10 2024

@author: hp
"""
'''本程序用于求取ET和GPP的单累计曲线和距平累积曲线。'''
#注意更改IGBP
import os
import re
import glob
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import matplotlib.cm as cm
import pwlf
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息 
#%%
def sms(df_all, varx, vary):   #做距平累积,varx指干旱指数，vary值变量值。
    df_sorted = df_all.sort_values(by=varx, ascending=False)  #以第1列为标准降序排序
    df_sorted[vary+'_cum'] = df_sorted[vary].cumsum()  # 计算第2列的逐元素累加值
    return df_sorted

def find_breakpoint(slopes, breakpoints):   # 找到符合条件的分界点，slopes是各分段的斜率，breakpoints是各分段点
    if all(s < 0 for s in slopes):
        bkp = np.nan
    elif all(s > 0 for s in slopes):        
        bkp = np.nan
    else:
        breakdict = {}
        for i in range(len(slopes) - 1):
            if (slopes[i] * slopes[i + 1] < 0) & (slopes[i] > slopes[i + 1]):
                breakdict[i+1] = breakpoints[i + 1]
        if len(breakdict)==1:
            bkp = breakdict[next(iter(breakdict.keys()))] #使用 next() 获取迭代器的第一个键
        else:
            bkplist = []
            for key in breakdict.keys():
                #if slopes[key] < slopes[key-1]:
                bkplist.append(breakdict[key])
            bkp = np.min(bkplist)
    return bkp
def tippoint(df_sorted, varx, vary):  #平滑数据，找到突变点,varx指干旱指数，vary值变量值。
    df_sorted1 = df_sorted.dropna(subset = [varx, vary])
    xs = df_sorted1[varx]
    ys = df_sorted1[vary+'_cum']
    
    df_pwlf = pwlf.PiecewiseLinFit(xs, ys, disp_res=False, degree = 1, seed = 14)  #分段线性回归    
    r_squared_values = {}   # 存储每个段数的 R-squared        
    for n_segments in range(2, 5):   # 尝试2段、3段和4段
        df_pwlf.fit(n_segments)        
        r_squared = df_pwlf.r_squared()# 计算 R-squared
        r_squared_values[n_segments] = r_squared                
    best_n_segments = max(r_squared_values, key=r_squared_values.get)  # 找到 R-squared 最大的段数        
    tppoints = df_pwlf.fit(best_n_segments)   #拟合最佳分段直线,获得分段点
    slopes = df_pwlf.slopes  # 获取分段斜率，在图中，增加斜率为负。
    dipoint = find_breakpoint(slopes, tppoints)  #点比线多一个，图中两侧端点会算上。从右往左排序
    return dipoint, df_pwlf
def yhat(df_sorted, varx, my_pwlf):  # 拟合分段拟合线用于绘制图像,varx指干旱指数，my_pwlf是拟合的曲线
    s1 = df_sorted[varx].copy()
    smin = np.min(s1)
    smax = np.max(s1)
    slen = len(s1)
    x_hat = np.linspace(smin, smax, slen)[::-1]
    y_hat = my_pwlf.predict(s1)
    return y_hat
#%%
dir_list = glob.glob(r'F:/phd1/V10/DBF/*/04SPEI/')
info_path = 'F:/phd1/V10/01allsite/02drought/SPEI_scale.xlsx'
site_frame = pd.read_excel(info_path, index_col=0, header=0)
dfs = []
theta = r'$\theta$'
for dd in dir_list:
    dd = dd.replace('\\', '/')
    substrings = re.split(r'/', dd)  # 按/分割
    igbp = substrings[3]
    siteid = substrings[4]
    tippoint_frame = pd.DataFrame(index=['ET','T','GPP','gc'],columns = ['siteid','SPEI','SMDI'])
    scale = int(site_frame.loc[site_frame['siteid'] == siteid, 'SPEI_scale'].values[0])        
    csvpath1 = 'F:/phd1/V10/'+igbp+'/'+siteid+'/04SPEI/SPEI'+str(scale*30)+'.csv'
    spei = pd.read_csv(csvpath1, index_col=0, parse_dates=True, header=0)
    csvpath2 = 'F:/phd1/V10/'+igbp+'/'+siteid+'/05SMDI/SMDI30.csv'
    smdi = pd.read_csv(csvpath2, index_col=0, parse_dates=True, header=0)
    csvpath3 = 'F:/phd1/V10/'+igbp+'/'+siteid+'/03data_flt/data_zscflt.csv'
    ori_frame = pd.read_csv(csvpath3, index_col=0, parse_dates=True, header=0)
    et_frame = ori_frame['et']
    gpp_frame = ori_frame['gpp']
    t_frame = ori_frame['t']
    csvpath4 = 'F:/phd1/V10/'+igbp+'/'+siteid+'/06WUE/gc_zscflt.csv'
    gc_frame = pd.read_csv(csvpath4, index_col=0, parse_dates=True, header=0)
    csvpath5 = 'F:/phd1/V10/'+igbp+'/'+siteid+'/05SMDI/spei_smdi.csv'
    spei_smdi = pd.read_csv(csvpath5, index_col=0, parse_dates=True, header=0)
    di_frame = pd.DataFrame(spei_smdi["DI"])
    common_df1 = pd.merge(spei, smdi, how='inner', left_index=True, right_index=True)
    common_df2 = pd.merge(common_df1, et_frame, how='inner', left_index=True, right_index=True)
    common_df3 = pd.merge(common_df2, gpp_frame, how='inner', left_index=True, right_index=True)
    common_df4 = pd.merge(common_df3, t_frame, how='inner', left_index=True, right_index=True)
    common_df5 = pd.merge(common_df4, gc_frame, how='inner', left_index=True, right_index=True)
    common_df6 = pd.merge(common_df5, di_frame, how='inner', left_index=True, right_index=True)
    common_df=common_df6.dropna(subset=['DI']) #删除nan位置所在的元素
    if len(common_df)>365:
        ########做距平累积
        speiet_sorted = sms(common_df, 'SPEI', 'et')
        smdiet_sorted = sms(common_df, 'SMDI', 'et')
        speigpp_sorted = sms(common_df, 'SPEI', 'gpp')
        smdigpp_sorted = sms(common_df, 'SMDI', 'gpp')
        speit_sorted = sms(common_df, 'SPEI', 't')
        smdit_sorted = sms(common_df, 'SMDI', 't')
        speigc_sorted = sms(common_df, 'SPEI', 'gc')
        smdigc_sorted = sms(common_df, 'SMDI', 'gc')
        ########做分段线性回归获得突变点
        try:
            speiet_points, speiet_pwlf = tippoint(speiet_sorted, 'SPEI', 'et')  # 获得突变点的干旱指数
            smdiet_points, smdiet_pwlf = tippoint(smdiet_sorted, 'SMDI', 'et')
            speigpp_points, speigpp_pwlf = tippoint(speigpp_sorted, 'SPEI', 'gpp')
            smdigpp_points, smdigpp_pwlf = tippoint(smdigpp_sorted, 'SMDI', 'gpp')
            speit_points, speit_pwlf = tippoint(speit_sorted, 'SPEI', 't')
            smdit_points, smdit_pwlf = tippoint(smdit_sorted, 'SMDI', 't')
            speigc_points, speigc_pwlf = tippoint(speigc_sorted, 'SPEI', 'gc')
            smdigc_points, smdigc_pwlf = tippoint(smdigc_sorted, 'SMDI', 'gc')
            #拟合分段拟合线并绘制折线图
            speiet_yhat = yhat(speiet_sorted, 'SPEI', speiet_pwlf)
            smdiet_yhat = yhat(smdiet_sorted, 'SMDI', smdiet_pwlf)
            speigpp_yhat = yhat(speigpp_sorted, 'SPEI', speigpp_pwlf)
            smdigpp_yhat = yhat(smdigpp_sorted, 'SMDI', smdigpp_pwlf)
            speit_yhat = yhat(speit_sorted, 'SPEI', speit_pwlf)
            smdit_yhat = yhat(smdit_sorted, 'SMDI', smdit_pwlf)
            speigc_yhat = yhat(speigc_sorted, 'SPEI', speigc_pwlf)
            smdigc_yhat = yhat(smdigc_sorted, 'SMDI', smdigc_pwlf)
            #写入单站点突变点表中
            tippoint_frame.loc['ET','SPEI'] = speiet_points
            tippoint_frame.loc['ET','SMDI'] = smdiet_points
            tippoint_frame.loc['ET','siteid'] = siteid
            tippoint_frame.loc['T','SPEI'] = speit_points
            tippoint_frame.loc['T','SMDI'] = smdit_points
            tippoint_frame.loc['T','siteid'] = siteid
            tippoint_frame.loc['GPP','SPEI'] = speigpp_points
            tippoint_frame.loc['GPP','SMDI'] = smdigpp_points
            tippoint_frame.loc['GPP','siteid'] = siteid
            tippoint_frame.loc['gc','SPEI'] = speigc_points
            tippoint_frame.loc['gc','SMDI'] = smdigc_points
            tippoint_frame.loc['gc','siteid'] = siteid
            print(siteid)
            os.makedirs('F:/phd1/V10/'+igbp+'/'+siteid+'/09amc', exist_ok=True)  #创建站点文件夹
            tippoint_frame.to_csv('F:/phd1/V10/'+igbp+'/'+siteid+'/09amc/tippoint.csv', index=True, header=True)
            dfs.append(tippoint_frame)
            #绘图
            parameters = {'axes.labelsize': 18,
                      'axes.titlesize': 25,
                      'xtick.labelsize': 20,
                      'ytick.labelsize': 20,
                      'figure.dpi': 300,
                      'lines.linewidth': 3,
                      'font.family': 'Arial'}
            plt.rcParams.update(parameters)
            fig, ax = plt.subplots(4, 2, figsize=(16, 12),dpi = 300)
    
            ax[0,0].plot(speiet_sorted['SPEI'], speiet_sorted['et_cum'], marker='o', linestyle='-', color='#3B89C7')
            ax[0,0].plot(speiet_sorted['SPEI'], speiet_yhat, linestyle='-', color='#E06D10')
            ax[0,0].axvline(x=speiet_points, color='#E63946', linestyle='--')  # 标记分界点
            ax[0,0].text(0.08, 0.1, f'{theta}  = {speiet_points:.2f}', transform=ax[0,0].transAxes, fontsize=20)
            ax[0,0].set_title('(a)', loc ='left', pad = 10, fontweight='bold')
            ax[0,0].set_ylabel('Cumulative ET_Z')
            ax[0,0].invert_xaxis()
    
            ax[0,1].plot(smdiet_sorted['SMDI'], smdiet_sorted['et_cum'], marker='o', linestyle='-', color='#3B89C7')
            ax[0,1].plot(smdiet_sorted['SMDI'], smdiet_yhat, linestyle='-', color='#E06D10')
            ax[0,1].axvline(x=smdiet_points, color='#E63946', linestyle='--')  # 标记分界点
            ax[0,1].text(0.08, 0.1, f'{theta}  = {smdiet_points:.2f}', transform=ax[0,1].transAxes, fontsize=20)
            ax[0,1].set_title('(b)', loc ='left', pad = 10, fontweight='bold')
            ax[0,1].invert_xaxis()
            
            ax[1,0].plot(speit_sorted['SPEI'], speit_sorted['t_cum'], marker='o', linestyle='-', color='#3B89C7')
            ax[1,0].plot(speit_sorted['SPEI'], speit_yhat, linestyle='-', color='#E06D10')
            ax[1,0].axvline(x=speit_points, color='#E63946', linestyle='--')  # 标记分界点
            ax[1,0].text(0.08, 0.1, f'{theta}  = {speit_points:.2f}', transform=ax[1,0].transAxes, fontsize=20)
            ax[1,0].set_title('(c)', loc ='left', pad = 10, fontweight='bold')
            ax[1,0].set_ylabel('Cumulative T_Z')
            ax[1,0].invert_xaxis()
    
            ax[1,1].plot(smdit_sorted['SMDI'], smdit_sorted['t_cum'], marker='o', linestyle='-', color='#3B89C7')
            ax[1,1].plot(smdit_sorted['SMDI'], smdit_yhat, linestyle='-', color='#E06D10')
            ax[1,1].axvline(x=smdit_points, color='#E63946', linestyle='--')  # 标记分界点
            ax[1,1].text(0.08, 0.1, f'{theta}  = {smdit_points:.2f}', transform=ax[1,1].transAxes, fontsize=20)
            ax[1,1].set_title('(d)', loc ='left', pad = 10, fontweight='bold')
            ax[1,1].invert_xaxis()
    
            ax[2,0].plot(speigpp_sorted['SPEI'], speigpp_sorted['gpp_cum'], marker='o', linestyle='-', color='#3B89C7')
            ax[2,0].plot(speigpp_sorted['SPEI'], speigpp_yhat, linestyle='-', color='#E06D10')
            ax[2,0].axvline(x=speigpp_points, color='#E63946', linestyle='--')  # 标记分界点
            ax[2,0].text(0.08, 0.1, f'{theta}  = {speigpp_points:.2f}', transform=ax[2,0].transAxes, fontsize=20)
            ax[2,0].set_title('(e)', loc ='left', pad = 10, fontweight='bold')
            ax[2,0].set_ylabel('Cumulative GPP_Z')
            ax[2,0].invert_xaxis()
    
            ax[2,1].plot(smdigpp_sorted['SMDI'], smdigpp_sorted['gpp_cum'], marker='o', linestyle='-', color='#3B89C7')
            ax[2,1].plot(smdigpp_sorted['SMDI'], smdigpp_yhat, linestyle='-', color='#E06D10')
            ax[2,1].axvline(x=smdigpp_points, color='#E63946', linestyle='--')  # 标记分界点
            ax[2,1].text(0.08, 0.1, f'{theta}  = {smdigpp_points:.2f}', transform=ax[2,1].transAxes, fontsize=20)
            ax[2,1].set_title('(f)', loc ='left', pad = 10, fontweight='bold')
            ax[2,1].invert_xaxis()
    
            ax[3,0].plot(speigc_sorted['SPEI'], speigc_sorted['gc_cum'], marker='o', linestyle='-', color='#3B89C7')
            ax[3,0].plot(speigc_sorted['SPEI'], speigc_yhat, linestyle='-', color='#E06D10')
            ax[3,0].axvline(x=speigc_points, color='#E63946', linestyle='--')  # 标记分界点
            ax[3,0].text(0.08, 0.1, f'{theta}  = {speigc_points:.2f}', transform=ax[3,0].transAxes, fontsize=20)
            ax[3,0].set_title('(g)', loc ='left', pad = 10, fontweight='bold')
            ax[3,0].set_xlabel('SPEI')
            ax[3,0].set_ylabel('Cumulative Gc_Z')
            ax[3,0].invert_xaxis()
    
            ax[3,1].plot(smdigc_sorted['SMDI'], smdigc_sorted['gc_cum'], marker='o', linestyle='-', color='#3B89C7')
            ax[3,1].plot(smdigc_sorted['SMDI'], smdigc_yhat, linestyle='-', color='#E06D10')
            ax[3,1].axvline(x=smdigc_points, color='#E63946', linestyle='--')  # 标记分界点
            ax[3,1].text(0.08, 0.1, f'{theta}  = {smdigc_points:.2f}', transform=ax[3,1].transAxes, fontsize=20)
            ax[3,1].set_title('(h)', loc ='left', pad = 10, fontweight='bold')
            ax[3,1].set_xlabel('SMDI')
            ax[3,1].invert_xaxis()
            plt.subplots_adjust(hspace=0.5)  # 增加0.5的垂直间距        
            plt.show()        
            fig.savefig('F:/phd1/V10/'+igbp+'/'+siteid+'/09amc/amc_egg.jpg',dpi=300, format='jpg', bbox_inches='tight') 
        except ValueError as e:
            pass
combined_df = pd.concat(dfs, axis=0) # 使用pd.concat函数进行上下合并
grouped = combined_df.groupby(combined_df.index)
#os.makedirs('F:/phd1/V10/'+igbp+'/01multisite/04amc', exist_ok=True)
# 保存每个分组为单独的 CSV 文件
for group_id, sub_df in grouped:
    filename = 'F:/phd1/V10/01allsite/07amc/'+group_id+'_tpoint.csv'  # 生成每个分组对应的文件名
    sub_df.to_csv(filename, index=True, header=True)  # 保存为 CSV 文件

#%%




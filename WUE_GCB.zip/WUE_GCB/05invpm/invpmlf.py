# -*- coding: utf-8 -*-
"""
Created on Fri May 10 15:45:12 2024

@author: LF
"""
'''本程序用于构建计算反彭曼公式必备的4个参数函数'''
import numpy as np
import pandas as pd

def calc_ga(ch, u, zm, zh, ustar):
    '''
    本函数用于计算空气动力学导度（aerodynamic conductence [m s-1]）
    
    input:
        method（int） :选择1用冠层高度计算，选择2用摩擦速度计算
        ch(float array, [m]): 冠层高度
        u(float array, [m s-1]): 风速
        zm(float array, [m]): 风速测量高度
        zh(float array, [m]): 湿度测量高度
        ustar(float array, [m s-1]): 摩擦速度
        
    output:
        ga(float array, [m s-1]): 空气动力学导度
    '''
    vk = 0.41 #von Karman constant
    if ustar is None:
        d = 2 * ch /3
        zom = 0.123 * ch
        zoh = 0.1 * zom
        arg1 = np.log((zm - d) / zom) * np.log((zh - d) / zoh)
        arg2 = vk**2*u
        ga = arg2 / arg1
    else:
        ga = 1/(u/ustar**2+6.2*ustar**-0.67)
    
    return ga

def cala_delta(ta):
    '''
    本函数用于计算饱和水汽压差与温度的斜率[Pa/degrees C]
    
    input:
        ta: 气温 （folat array, [degrees C]）
    output:
        delta: 斜率 （float array, Pa/degrees C）
    '''
    e_sat = 611 * np.exp((17.27 * ta) / (237.3 + ta))  #Saturated vapor pressure of air [Pa] 空气饱和蒸汽压
    delta = (2508.3 / (237.3 + ta) ** 2) * e_sat / 611 * 1000 #Slope of Clausius-Clapeyron relation [Pa/degrees C] 克劳修斯-克拉珀龙关系的斜率
    return delta

def calc_rho(press, ta):
    '''
    本函数用于计算空气密度（Average density of air [kg m-3]）
    
    input:
        press： 大气压（floar array, Pa）
        ta: 气温 （folat array, [degrees C]）
    output:
        rho: 空气密度（loat array, [kg m-3]）
    '''
    R_g = 8.314 #Universal gas constant [J/K/mol] 通用气体常数
    M_a = 0.029 #Molecular weight of air [kg/mol] 空气的分子量    
    rho = press / (R_g * (ta + 273.15)) * M_a
    return rho

def calc_gam(press, ta):
    '''
    本函数用于计算干湿表常数(Psychrometric constant, [Pa/degrees C])
    input:
        press： 大气压（floar array, Pa）
        ta: 气温 （folat array, [degrees C]）
    output:
        gamma: 干湿表常数(Psychrometric constant, [Pa/degrees C])
    '''
    c_p = 1012 #Specific heat at constant pressure [J/kg/K] 恒压比热
    M_w = 0.018  #Molecular weight of water [kg/mol] 水的摩尔质量
    M_a = 0.029   # Molecular weight of air [kg/mol] 空气的摩尔质量
    lamda = 2.45e6 #Latent heat of vaporization [J/kg] 汽化潜热
    gamma = c_p * press / ((M_w / M_a) * lamda)
    return gamma

def vel2mol(g_mps, press, ta):
    '''
    本函数用于将m s-1单位转换成mol m-2 s-1
    input:
        press： 大气压（floar array, Pa）
        ta: 气温 （folat array, [degrees C]）
    output:
        gc_mol: 冠层导度(mol m-2 s-1)
    '''    
    R_g = 8.314   #  Universal gas constant [J/K/mol]   
         
    conv = press / (R_g * (ta + 273.15))     #Calculate conversion factor from Ideal gas law [mol/m^3]
     
    gc_mol = g_mps * conv    #Converted conductance [mol air/m^2/s]  
    return gc_mol
    

def calc_gc(le, rnet, gf, he, vpd, gamma, ga, delta, rho, cp, press, ta):
    '''
    本函数利用反彭曼公式计算冠层导度(mol m-2 s-1)
    input:
        le: 潜热通量(W m-2)
        rnet: 净辐射(W m-2)
        gf: 土壤热通量(W m-2)
        vpd: 水汽压差(Pa)
        gamma: 干湿表常数(Psychrometric constant, [Pa/degrees C])
        ga(float array, [m s-1]): 空气动力学导度
        delta: 斜率 （float array, Pa/degrees C）
        rho: 空气密度（loat array, [kg m-3]）
        cp = 1012 Specific heat at constant pressure [J/kg/K] 恒压比热
        press： 大气压（floar array, Pa）
        ta: 气温 （folat array, [degrees C]）       
    output:
        gc: 冠层导度(mol m-2 s-1)
    '''
    if gf is None:
        gc_mps = (gamma * le * ga) / (delta * (le + he) + rho * cp * ga * vpd - le * (delta + gamma))  #m s-1
        gc_mol = vel2mol(gc_mps, press, ta)  #mol m-2 s-1
    else:
        gc_mps = (gamma * le * ga) / (delta * (rnet - gf) + rho * cp * ga * vpd - le * (delta + gamma))  #m s-1
        gc_mol = vel2mol(gc_mps, press, ta)  #mol m-2 s-1
    return gc_mol
    
    



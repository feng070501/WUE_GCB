# -*- coding: utf-8 -*-
"""
Created on Tue Apr 16 21:20:33 2024

@author: LF
"""
'''本程序利用最大pearson相关系数计算哪个月尺度的SPEI与SMDI的拟合越好。'''
#注意更改IGBP
import numpy as np
import pandas as pd
import glob
import re
import os
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%
multiples_of_30 = [i for i in range(30, 361, 30)]  
smdipath = glob.glob('F:/phd1/V6/ENF/*/05SMDI/SMDI30.csv')
for ss in smdipath:
    ss = ss.replace('\\', '/')
    substrings = re.split(r'/', ss)  # 按/分割
    igbp = substrings[3]
    siteid = substrings[4]
    smdi = pd.read_csv(ss, index_col=0, parse_dates=True, header=0)
    cc_list=pd.Series(index = list(range(1,13)))
    zz=1
    for mm in multiples_of_30:
        csvpath1 = 'F:/phd1/V6/'+igbp+'/'+siteid+'/04SPEI/SPEI'+str(mm)+'.csv'
        spei = pd.read_csv(csvpath1, index_col=0, parse_dates=True, header=0)
        combined_df = pd.concat([spei, smdi], axis=1)
        # 使用 any() 函数检查每一行是否含有 NaN 值
        mask = combined_df.isnull().any(axis=1)    
        # 根据掩码筛选出符合条件的行
        cleaned_combined_df = combined_df[~mask]   
        # 分割合并后的 DataFrame，得到删除好的 df1 和 df2
        df_spei2 = cleaned_combined_df[['SPEI']].to_numpy().flatten()
        df_smdi2 = cleaned_combined_df[['SMDI']].to_numpy().flatten()
    
        cc = np.corrcoef(df_spei2, df_smdi2)[0, 1]
        cc_list[zz] = np.abs(cc)
        zz+=1
    df = pd.DataFrame(np.array(cc_list),index = list(range(1,13)),columns=['cor'])
    df.to_csv('F:/phd1/V6/'+igbp+'/'+siteid+'/04SPEI/max_cc.csv', index=True, header=True)
    print(siteid)


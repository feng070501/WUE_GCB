# -*- coding: utf-8 -*-
"""
Created on Thu Jun 20 15:26:11 2024

@author: LF
"""
'''本程序用于绘制站点SPEI尺度分布图。'''
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
from matplotlib.colors import Normalize
from matplotlib.ticker import MaxNLocator
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%读入站点信息并统计分类
file_path = 'F:/phd1/V10/01allsite/02drought/SPEI_scale.xlsx'
latlon_df = pd.read_excel(file_path)
#%%绘制空间分布图
parameters = {'axes.labelsize': 30,
          'axes.titlesize': 30,
          'xtick.labelsize': 30,
          'ytick.labelsize': 30,
          'figure.dpi': 300,    
          'font.family': 'Arial'}
plt.rcParams.update(parameters)

fig, ax = plt.subplots(1, 1, figsize=(15, 10), dpi=300, subplot_kw={'projection': ccrs.PlateCarree()})
proj = ccrs.PlateCarree()  #中央经线为东经10度的等经纬投影
extent = [-180, 180, -90, 90]  #西东南北边界
norm = Normalize(vmin=latlon_df['SPEI_scale'].min(), vmax=latlon_df['SPEI_scale'].max())  #固定值与颜色映射
cmaps = plt.cm.YlOrBr #选择colorbar
def ax_set(ax):  #设置子图参数
    ax.set_extent(extent)  #设定空间范围
    land_feature = cfeature.NaturalEarthFeature(category='physical',name='land',scale='50m',facecolor='#D3D3D3')   # 设置陆地的颜色        
    ax.add_feature(land_feature, zorder=0)  # 添加自定义的陆地特征到绘图
    ax.add_feature(cfeature.OCEAN)   #添加海洋
    ax.coastlines(resolution = '50m')  #添加海岸线
    #ax.add_feature(cfeature.BORDERS,lw=0.5)
    gl = ax.gridlines(crs=proj, draw_labels=True, linewidth=1.2, color='k', alpha=0.5, linestyle='--')  # 设置网格点属性
    gl.top_labels = False
    gl.right_labels = False
    gl.xlabel_style = {'size': 24}
    gl.ylabel_style = {'size': 24}
    return gl
gl = ax_set(ax)
# 定义形状映射
shape_dict = {
    'EBF': 'D',  # 圆形
    'DBF': 's',  # 方形
    'ENF': '^',  # 三角形
    'GRA': 'o',  # 菱形
    'MIF': 'H',  # 倒三角形
    'SHR': 'P',  # 五边形
    'SAV': '*'  # 星形    
}
# 绘制站点
for rr in range(len(latlon_df)):
    row = latlon_df.iloc[rr,:]
    igbp = row['igbp']            
    sc = ax.scatter(row['lon'], row['lat'], c=[cmaps(norm(row['SPEI_scale']))], 
                    s=100, edgecolor='k', marker=shape_dict[igbp], transform=ccrs.PlateCarree())  #绘制散点图    
ax.set_title('(A) SPEI scale', pad=15)
# 创建图例
handles = [mlines.Line2D([], [], color='black', marker=shape, linestyle='None', markersize=20, label=igbp) for igbp, shape in shape_dict.items()]
fig.legend(handles=handles, loc='right', fontsize=25, bbox_to_anchor=(1.05, 0.55), frameon=False)
sm = plt.cm.ScalarMappable(cmap=cmaps, norm=norm)
sm.set_array([])  # 仅用于colorbar，不需要实际数据
cbar = fig.colorbar(sm, ax = ax, orientation='horizontal', fraction=0.08, pad=0.08)
#cbar.set_label('months', fontsize=25)  # 设置colorbar的标签字体大小
cbar.ax.tick_params(labelsize=25)  # 设置colorbar刻度的字体大小
plt.show()
fig.savefig("F:/phd1/V10/01allsite/02drought/SPEI_scale.jpg",dpi=300, format='jpg', bbox_inches='tight')
#%%绘制欧洲图
parameters = {'axes.labelsize': 30,
          'axes.titlesize': 30,
          'xtick.labelsize': 30,
          'ytick.labelsize': 30,
          'figure.dpi': 300,    
          'font.family': 'Arial'}
plt.rcParams.update(parameters)

fig, ax = plt.subplots(1, 1, figsize=(10, 10), dpi=300, subplot_kw={'projection': ccrs.PlateCarree()})
proj = ccrs.PlateCarree()  #中央经线为东经10度的等经纬投影
extent = [-5, 20, 40, 60]  #西东南北边界
norm = Normalize(vmin=latlon_df['SPEI_scale'].min(), vmax=latlon_df['SPEI_scale'].max())  #固定值与颜色映射
cmaps = plt.cm.YlOrBr #选择colorbar
def ax_set(ax):  #设置子图参数
    ax.set_extent(extent)  #设定空间范围
    land_feature = cfeature.NaturalEarthFeature(category='physical',name='land',scale='50m',facecolor='#D3D3D3')   # 设置陆地的颜色        
    ax.add_feature(land_feature, zorder=0)  # 添加自定义的陆地特征到绘图
    ax.add_feature(cfeature.OCEAN)   #添加海洋
    ax.coastlines(resolution = '50m')  #添加海岸线    
    gl = ax.gridlines(crs=proj, draw_labels=True, linewidth=1.2, color='k', alpha=0.5, linestyle='--')  # 设置网格点属性
    gl.top_labels = False
    gl.right_labels = False
    gl.bottom_labels = False
    gl.left_labels = False
    return gl
gl = ax_set(ax)
# 定义形状映射
shape_dict = {
    'EBF': 'D',  # 圆形
    'DBF': 's',  # 方形
    'ENF': '^',  # 三角形
    'GRA': 'o',  # 菱形
    'MIF': 'H',  # 倒三角形
    'SHR': 'P',  # 五边形
    'SAV': '*'  # 星形    
}
# 绘制站点
for rr in range(len(latlon_df)):
    row = latlon_df.iloc[rr,:]
    igbp = row['igbp']            
    sc = ax.scatter(row['lon'], row['lat'], c=[cmaps(norm(row['SPEI_scale']))], 
                    s=150, edgecolor='k', marker=shape_dict[igbp], transform=ccrs.PlateCarree())  #绘制散点图    
plt.show()
fig.savefig("F:/phd1/V10/01allsite/02drought/SPEI_euro.jpg",dpi=300, format='jpg', bbox_inches='tight')
#%%绘制美洲图
parameters = {'axes.labelsize': 30,
          'axes.titlesize': 30,
          'xtick.labelsize': 30,
          'ytick.labelsize': 30,
          'figure.dpi': 300,    
          'font.family': 'Arial'}
plt.rcParams.update(parameters)

fig, ax = plt.subplots(1, 1, figsize=(10, 10), dpi=300, subplot_kw={'projection': ccrs.PlateCarree()})
proj = ccrs.PlateCarree()  #中央经线为东经10度的等经纬投影
extent = [-125, -65, 25, 55]  #西东南北边界
norm = Normalize(vmin=latlon_df['SPEI_scale'].min(), vmax=latlon_df['SPEI_scale'].max())  #固定值与颜色映射
cmaps = plt.cm.YlOrBr #选择colorbar
def ax_set(ax):  #设置子图参数
    ax.set_extent(extent)  #设定空间范围
    land_feature = cfeature.NaturalEarthFeature(category='physical',name='land',scale='50m',facecolor='#D3D3D3')   # 设置陆地的颜色        
    ax.add_feature(land_feature, zorder=0)  # 添加自定义的陆地特征到绘图
    ax.add_feature(cfeature.OCEAN)   #添加海洋
    ax.coastlines(resolution = '50m')  #添加海岸线    
    gl = ax.gridlines(crs=proj, draw_labels=True, linewidth=1.2, color='k', alpha=0.5, linestyle='--')  # 设置网格点属性
    gl.top_labels = False
    gl.right_labels = False
    gl.bottom_labels = False
    gl.left_labels = False
    return gl
gl = ax_set(ax)
# 定义形状映射
shape_dict = {
    'EBF': 'D',  # 圆形
    'DBF': 's',  # 方形
    'ENF': '^',  # 三角形
    'GRA': 'o',  # 菱形
    'MIF': 'H',  # 倒三角形
    'SHR': 'P',  # 五边形
    'SAV': '*'  # 星形    
}
# 绘制站点
for rr in range(len(latlon_df)):
    row = latlon_df.iloc[rr,:]
    igbp = row['igbp']            
    sc = ax.scatter(row['lon'], row['lat'], c=[cmaps(norm(row['SPEI_scale']))], 
                    s=90, edgecolor='k', marker=shape_dict[igbp], transform=ccrs.PlateCarree())  #绘制散点图    
plt.show()
fig.savefig("F:/phd1/V10/01allsite/02drought/SPEI_ameri.jpg",dpi=300, format='jpg', bbox_inches='tight')
#%%绘制直方图
parameters = {'axes.labelsize': 30,
          'axes.titlesize': 30,
          'xtick.labelsize': 30,
          'ytick.labelsize': 30,
          'figure.dpi': 300,    
          'font.family': 'Arial'}
plt.rcParams.update(parameters)

fig, ax = plt.subplots(1, 1, figsize=(10, 10), dpi=300)
ax.hist(latlon_df['SPEI_scale'], bins=12, density=True, alpha=0.6, color='#FF7F50', edgecolor='black')
ax.xaxis.set_major_locator(MaxNLocator(integer=True))
ax.set_xlabel('SPEI scale')
ax.set_ylabel('Frequency density')
plt.show()
fig.savefig("F:/phd1/V10/01allsite/02drought/SPEI_scale_frequency.jpg",dpi=300, format='jpg', bbox_inches='tight')

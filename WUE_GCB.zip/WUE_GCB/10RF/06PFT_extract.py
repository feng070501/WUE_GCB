# -*- coding: utf-8 -*-
"""
Created on Mon Oct 14 21:23:55 2024

@author: LF
"""
'''本程序用于提取有关植被功能性状的统计量'''
import os
import glob
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import rioxarray as rxr
import geopandas as gpd
from rasterstats import zonal_stats
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%需要进行指数变换
def ext_pft(invari, outvari):
    shp_file = "F:/phd1/V6/01allsite/08RF/sitefilter/filter_buffer.shp"
    gdf = gpd.read_file(shp_file, encoding='utf-8')
    tif_tif = rxr.open_rasterio('F:/phd1/V6/01allsite/08RF/rasterdata/PFT/'+invari+'_ln.tif', masked=True).squeeze()
    # 直接替换无数据值为 NaN
    nodata_value = tif_tif.rio.nodata  # 获取 nodata 值
    tif_tif = tif_tif.where(tif_tif != nodata_value)  # 掩膜 nodata
    tif_exp = np.exp(tif_tif)
    if gdf.crs != tif_exp.rio.crs:
        gdf = gdf.to_crs(tif_exp.rio.crs)
    plt.imshow(tif_exp)
    plt.show()
    tif_ext = zonal_stats(
        gdf,
        tif_exp.values,
        affine=tif_exp.rio.transform(),
        stats="mean",  # 可以指定多个统计量，例如 "min", "max", "median", "mean" 等
        geojson_out=True,  # 如果需要保留与矢量面对应的信息
        multiprocessing=True,
        all_touched=True
    )
    # 从 stats 提取 siteid 和 mean 值
    feature_data = [{"siteid": feature["properties"]["siteid"], "mean_value": feature["properties"]["mean"]} for feature in tif_ext]
    # 构建 DataFrame
    tif_ext1 = pd.DataFrame(feature_data)
    tif_ext1.to_csv('F:/phd1/V6/01allsite/08RF/varix/'+outvari+'.csv', index=True, header=True, float_format='%.4f')
    return tif_ext1
data_dir = glob.glob('F:/phd1/V6/01allsite/08RF/rasterdata/PFT/*_ln.tif')
for dd in data_dir:      
    vari = os.path.splitext(os.path.basename(dd))[0][0:-3]  #提取不带扩展名的文件名
    new_df = ext_pft(vari,vari)
    print(vari)
#%%直接提取
def ext_pft(invari, outvari):
    shp_file = "F:/phd1/V6/01allsite/08RF/sitefilter/filter_buffer.shp"
    gdf = gpd.read_file(shp_file, encoding='utf-8')
    tif_tif = rxr.open_rasterio('F:/phd1/V6/01allsite/08RF/rasterdata/PFT/'+invari+'.tif', masked=True).squeeze()
    # 直接替换无数据值为 NaN
    nodata_value = tif_tif.rio.nodata  # 获取 nodata 值
    tif_tif = tif_tif.where(tif_tif != nodata_value)  # 掩膜 nodata
    if gdf.crs != tif_tif.rio.crs:
        gdf = gdf.to_crs(tif_tif.rio.crs)
    plt.imshow(tif_tif)
    plt.show()
    tif_ext = zonal_stats(
        gdf,
        tif_tif.values,
        affine = tif_tif.rio.transform(),
        stats = "mean",  # 可以指定多个统计量，例如 "min", "max", "median", "mean" 等
        geojson_out = True,  # 如果需要保留与矢量面对应的信息
        multiprocessing = True,
        all_touched = True
    )
    # 从 stats 提取 siteid 和 mean 值
    feature_data = [{"siteid": feature["properties"]["siteid"], "mean_value": feature["properties"]["mean"]} for feature in tif_ext]
    # 构建 DataFrame
    tif_ext1 = pd.DataFrame(feature_data)
    tif_ext1.to_csv('F:/phd1/V6/01allsite/08RF/varix/'+outvari+'.csv', index=True, header=True, float_format='%.4f')
    return tif_ext1
vari_list = ['LDMC','LNC','LPC','P50','PSR','SLA', 'VCH', 'Vcmax']
for vv in vari_list:          
    new_df = ext_pft(vv,vv)
    print(vv)
#%%


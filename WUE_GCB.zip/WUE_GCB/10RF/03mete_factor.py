# -*- coding: utf-8 -*-
"""
Created on Mon Oct 14 19:55:18 2024

@author: LF
"""
'''本程序用于计算有关气象的统计量'''
#注意更改多处4/5/6阶段
import os
import re
import glob 
import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%
pre_frame = pd.DataFrame(columns = ['siteid', 'pre'])
tmean_frame = pd.DataFrame(columns = ['siteid', 'tmean'])
tmax_frame = pd.DataFrame(columns = ['siteid', 'tmax'])
vpd_frame = pd.DataFrame(columns = ['siteid', 'vpd'])
rnet_frame = pd.DataFrame(columns = ['siteid', 'rnet'])
ws_frame = pd.DataFrame(columns = ['siteid', 'ws'])
swc_frame = pd.DataFrame(columns = ['siteid', 'swc'])
dir_list = glob.glob(r'F:/phd1/V10/*/*/01data_dd/data_ori.csv')
rr = 0
for dd in dir_list:
    dd = dd.replace('\\', '/')
    substrings = re.split(r'/', dd)  # 按/分割
    igbp = substrings[3]
    siteid = substrings[4]                
    
    data = pd.read_csv(dd, index_col=0, parse_dates=True, header=0)
    pre_data = data['pre']
    ta_data = data['ta']
    vpd_data = data['vpd']
    rnet_data = data['rnet']
    ws_data = data['ws']
    swc_data = data['swc']
    csvpath6 = 'F:/phd1/V10/'+igbp+'/'+siteid+'/05SMDI/spei_smdi.csv'
    spei_smdi = pd.read_csv(csvpath6, index_col=0, parse_dates=True, header=0)
    grouped = spei_smdi.groupby('DI') # 使用groupby函数按第一列分组    
    if 6 in grouped.groups:
        group_data = grouped.get_group(6)        
        print(siteid)          
        #降水
        pre_group = pre_data.loc[group_data.index]
        pre_frame.loc[rr,'siteid'] = siteid
        pre_frame.loc[rr,'pre'] = np.nansum(pre_group.values)
        #气温
        ta_group = ta_data.loc[group_data.index]
        tmean_frame.loc[rr,'siteid'] = siteid
        tmean_frame.loc[rr,'tmean'] = np.nanmean(ta_group.values)
        #最高温
        tmax_group = ta_data.loc[group_data.index]
        tmax_frame.loc[rr,'siteid'] = siteid
        tmax_frame.loc[rr,'tmax'] = np.nanmax(ta_group.values)
        #vpd
        vpd_group = vpd_data.loc[group_data.index]
        vpd_frame.loc[rr,'siteid'] = siteid
        vpd_frame.loc[rr,'vpd'] = np.nanmean(vpd_group.values)
        #rnet
        rnet_group = rnet_data.loc[group_data.index]
        rnet_frame.loc[rr,'siteid'] = siteid
        rnet_frame.loc[rr,'rnet'] = np.nanmean(rnet_group.values)
        #ws
        ws_group = ws_data.loc[group_data.index]
        ws_frame.loc[rr,'siteid'] = siteid
        ws_frame.loc[rr,'ws'] = np.nanmean(ws_group.values)
        #swc
        swc_group = swc_data.loc[group_data.index]
        swc_frame.loc[rr,'siteid'] = siteid
        swc_frame.loc[rr,'swc'] = np.nanmean(swc_group.values)
        rr+=1
    else:
        print(siteid,"没有6的数据。")
pre_frame.to_csv('F:/phd1/V10/01allsite/08RF/varix_6/pre_6.csv', index=True, header=True, float_format='%.4f')            
tmean_frame.to_csv('F:/phd1/V10/01allsite/08RF/varix_6/tmean_6.csv', index=True, header=True, float_format='%.4f')
tmax_frame.to_csv('F:/phd1/V10/01allsite/08RF/varix_6/tmax_6.csv', index=True, header=True, float_format='%.4f')
vpd_frame.to_csv('F:/phd1/V10/01allsite/08RF/varix_6/vpd_6.csv', index=True, header=True, float_format='%.4f')
rnet_frame.to_csv('F:/phd1/V10/01allsite/08RF/varix_6/rnet_6.csv', index=True, header=True, float_format='%.4f')
ws_frame.to_csv('F:/phd1/V10/01allsite/08RF/varix_6/ws_6.csv', index=True, header=True, float_format='%.4f')
swc_frame.to_csv('F:/phd1/V10/01allsite/08RF/varix_6/swc_6.csv', index=True, header=True, float_format='%.4f')

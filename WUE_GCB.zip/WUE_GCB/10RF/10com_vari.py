#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct 18 15:19:41 2024

@author: lifeng
"""
'''本程序用于聚合所有变量，为XGboost做数据准备。'''
#注意更改多处4/5/6阶段
import pandas as pd
import glob
import os
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%
# 设定两个文件夹路径
folder1 = "F:/phd1/V10/01allsite/08RF/varix_6/"  # 替换成你的文件夹路径
folder2 = "F:/phd1/V10/01allsite/08RF/variy_6/"
# 获取所有文件路径（假设是 CSV 文件）
filesx = sorted(glob.glob(os.path.join(folder1, "*.csv")))
filesy = sorted(glob.glob(os.path.join(folder2, "*.csv")))
# 合并两个文件夹的文件列表
all_files = filesx + filesy
#%%
siteid1 = pd.read_csv('F:/phd1/V10/01allsite/08RF/varix_6/ai.csv', index_col=0, header=0)['siteid']
final_df = pd.DataFrame(siteid1)
for ff in all_files:
    df = pd.read_csv(ff, index_col=0, header=0)
    df.rename(columns={df.columns[0]: 'siteid'}, inplace=True)
    df_unique = df.drop_duplicates(subset='siteid', keep='first')  # 去掉重复的siteid，只保留第一次出现的  
    col_name = os.path.splitext(os.path.basename(ff))[0]  #获取变量
    val_col = df_unique.iloc[:,1]
    # 对第二列进行最小最大归一化
    df_unique[col_name+'_norm'] = ((val_col - val_col.min()) / (val_col.max() - val_col.min()))*100
    # mean_val = val_col.mean(skipna=True)
    # std_val = val_col.std(skipna=True)
    # df_unique[col_name + '_zscore'] = (val_col - mean_val) / std_val
    df_unique.drop(df_unique.columns[1], axis=1, inplace=True)   # 删除原有的第二列            
    final_df = pd.merge(final_df, df_unique, on='siteid', how='left')  #根据站点名称拼接
    print(ff)
final_df1 = final_df.dropna() #只要有nan的行删除
final_df1.set_index('siteid', inplace=True)   # 将第一列作为索引
final_df1.columns = final_df1.columns.str.split('_').str[0].str.upper()    
final_df1.to_csv('F:/phd1/V10/01allsite/08RF/factors/factors_6.csv', index=True, header=True, float_format='%.4f')

#%%


#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 17 21:28:54 2024

@author: lifeng
"""
'''本程序用于从hd5数据中提取站点信息。'''
import os
import glob
import pandas as pd
import numpy as np
import hdf5storage
import rioxarray as rxr
import xarray as xr
import matplotlib.pyplot as plt
import geopandas as gpd
from rasterstats import zonal_stats
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%
vari='WD'
# 1. 读取Excel文件中的站点经纬度
shp_file = "F:/phd1/V6/01allsite/08RF/sitefilter/filter_buffer.shp"
gdf = gpd.read_file(shp_file, encoding='utf-8') 
# 2. 加载MAT文件并提取数据
mat_file = 'F:/phd1/V6/01allsite/08RF/rasterdata/PFT/'+vari+'.mat'
mat_data = hdf5storage.loadmat(mat_file)

vari_list = list(mat_data.keys())
wd_mean = mat_data['wd_mean']  # 根据具体数据集名称进行替换
num_latitudes = wd_mean.shape[0]
num_longitudes = wd_mean.shape[1]

# 创建均匀的纬度和经度
latitudes = np.linspace(90, -90, num_latitudes)  # 纬度从90到-90
longitudes = np.linspace(-180, 180, num_longitudes)  # 经度从-180到180
# 创建 DataFrame
wd_df = pd.DataFrame(wd_mean, index=latitudes, columns=longitudes)
plt.imshow(wd_df, cmap='viridis', interpolation='nearest')
plt.show()
# 将 DataFrame 转换为 xarray DataArray
data_array = xr.DataArray(wd_df.values, coords=[("lat", latitudes), ("lon", longitudes)])
# 设置地理坐标
data_array = data_array.rio.set_spatial_dims(x_dim="lon", y_dim="lat")
data_array.rio.write_crs("EPSG:4326", inplace=True)
# 保存为 GeoTIFF
outif = 'F:/phd1/V6/01allsite/08RF/rasterdata/temp/'+vari+'.tif'
data_array.rio.to_raster(outif)
#%%
tif_ext = zonal_stats(
    gdf,
    data_array.values,
    affine=data_array.rio.transform(),
    stats="mean",  
    geojson_out=True,  # 如果需要保留与矢量面对应的信息
    multiprocessing=True,
    all_touched=True
)
# 从 stats 提取 siteid 和 mean 值
feature_data = [{"siteid": feature["properties"]["siteid"], "mean_value": feature["properties"]["mean"]} for feature in tif_ext]
# 构建 DataFrame
tif_ext1 = pd.DataFrame(feature_data)
tif_ext1.to_csv('F:/phd1/V6/01allsite/08RF/varix/'+vari+'.csv', index=True, header=True, float_format='%.4f')



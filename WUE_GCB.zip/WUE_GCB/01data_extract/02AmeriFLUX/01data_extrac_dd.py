# -*- coding: utf-8 -*-
"""
Created on Sun Apr 21 20:54:23 2024

@author: LF
"""
'''本程序用于提取Ameriflux通量站点的各变量数据。'''
#注意实时更换IGBP
import pandas as pd
import numpy as np
import glob
import os
import re
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%
def cycle_nan(series):  #去除循环的异常值
    for i in range(len(series)-4):
        if (series[i] == series[i+3]) and (series[i+1] == series[i+4]) and series[i]!=0:
            series[i] = np.nan
    return series
def fluxextract(data_df, vari):   #筛选有效的数据    
    try:
        if data_df[vari+'_QC'].isna().all():            
            col = data_df[vari]
        else:
            #根据质量控制QC筛选数据
            data_df.loc[(data_df[vari+'_QC'] > 1) | (data_df[vari+'_QC'] < 0) | (data_df[vari+'_QC'].isna()), vari] = np.nan         
            col = data_df[vari]        
        return col
    except KeyError as e:
        col = pd.Series(np.nan, index=data_df.index)
        print(siteid, f'站点缺变量{e}')
        return col
#变量代号
vari_list = ['P_F','TA_F', 'SW_IN_F', 'PA_F', 'SWC_F_MDS_1', 'G_F_MDS', 'VPD_F', 'WS_F', 'USTAR', 'NETRAD', 'CO2_F_MDS']
#变量简写
variname_list = ['pre', 'ta', 'swin', 'pa', 'swc', 'gf', 'vpd', 'ws', 'ustar', 'rnet', 'co2']
#%%拼接两个时段的csv
# 使用pandas读取CSV文件
csvpath_list = glob.glob('F:/phd1/rawdata/AmeriFLUX/DBF/*/AMF_*_FLUXNET_SUBSET_DD_*_3-5.csv')
for pp in csvpath_list:
    pp = pp.replace('\\', '/')
    substrings = re.split(r'/', pp)  # 按/分割
    igbp = substrings[4]
    siteid = substrings[5]    
    csv_df = pd.read_csv(pp, index_col='TIMESTAMP', parse_dates=True, header=0) 
    csv_df.replace(-9999, np.nan, inplace=True)
    datadf = pd.DataFrame(index = csv_df.index, columns=variname_list)
    for vv in range(len(vari_list)):
        col = fluxextract(csv_df, vari_list[vv])
        datadf[variname_list[vv]] = col 
    #提取LE    
    le = csv_df['LE_CORR']
    if le.isna().all():        
        le = csv_df['LE_F_MDS']
    le = cycle_nan(le)
    le[le < 0] = np.nan
    datadf['le'] = le
    #提取H    
    he = csv_df['H_CORR']
    if he.isna().all():        
        he = csv_df['H_F_MDS']
    he = cycle_nan(he)
    he[he < 0] = np.nan
    datadf['he'] = he
    #提取GPP    
    gpp = csv_df['GPP_NT_VUT_REF']
    gpp = cycle_nan(gpp)
    gpp[gpp < 0] = np.nan
    datadf['gpp'] = gpp
    #提取呼吸    
    reco = csv_df['RECO_NT_VUT_REF']
    reco = cycle_nan(reco)    
    datadf['reco'] = reco
    
    #提取蒸腾量    
    ta = datadf['ta']    
    le = datadf['le']    
    lamda = (2.501-2.361e-3*ta.values)
    et = le.values*86400*1e-6/lamda  #MJ/m2到mm/d
    et1 = np.where(et < 0, 0, et)
    datadf['et'] = et1    
    #单位换算
    datadf['pa_pa'] = datadf['pa'].values*1000.0    
    datadf['vpd_pa'] = datadf['vpd'].values*100.0        
    try:        
        datadf['swc_m3'] = datadf['swc'].values*0.01        
    except:
        datadf['swc_m3'] = pd.Series(np.nan, index=datadf.index)
    datadf.to_csv('F:/phd1/V6/'+igbp+'/'+siteid+'/01data_dd/data_ori.csv', float_format='%.4f')          
    print(siteid)


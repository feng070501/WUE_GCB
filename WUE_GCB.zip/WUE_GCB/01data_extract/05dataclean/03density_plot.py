#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan  6 22:15:22 2025

@author: lifeng
"""
'''本程序用于绘制带密度的散点图'''
import re
import glob
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import gaussian_kde
from matplotlib.colors import ListedColormap
from sklearn.metrics import r2_score
#%%
parameters = {'axes.labelsize': 30,
          'axes.titlesize': 30,
          'xtick.labelsize': 25,
          'ytick.labelsize': 25,
          'figure.dpi': 300,    
          'font.family': 'Arial',
          'axes.titlepad': 20}
plt.rcParams.update(parameters)
#读入数据
site_path = 'F:/phd1/V6/01allsite/09et_part/flux_sap.xlsx'
sap_sitedf = pd.read_excel(site_path, index_col =0, header =0)
flux_path = 'F:/phd1/V6/01allsite/01siteinfo/siteinfo_dem.csv'
flux_sitedf = pd.read_csv(flux_path, index_col =0, header =0)
sap_paths = glob.glob('F:/phd1/V6/01allsite/09et_part/*/t_sap.csv')
for ss in sap_paths:
    ss = ss.replace('\\', '/')
    sap_site = re.split(r'/', ss)[5]
    flux_site = sap_sitedf.loc[sap_sitedf['sap_siteid']==sap_site,'siteid'].values[0]
    igbp = flux_sitedf.loc[flux_sitedf['siteid']==flux_site,'igbp'].values[0]
    flux_paths = 'F:/phd1/V6/'+igbp+'/'+flux_site+'/01data_dd/data_ori.csv'
    t_df = pd.read_csv(flux_paths, index_col=0, parse_dates=True, header=0)['t']
    sap_df = pd.read_csv(ss, index_col=0, parse_dates=True, header=0)['Et']
    df = pd.concat([t_df, sap_df], axis=1)
    df1 = df.dropna()
    #计算每个点的密度
    xy = np.vstack([df1['Et'], df1['t']])
    density = gaussian_kde(xy)(xy)
    r2 = df1.corr().iloc[0, 1]
    # 根据密度对点进行着色
    fig, ax = plt.subplots(figsize=(12, 8))
    # 截取 colormap 的部分范围
    original_cmap = plt.cm.gist_heat_r
    truncated_cmap = ListedColormap(original_cmap(np.linspace(0.1, 0.9, 256)))
    scatter = ax.scatter(df1['Et'], df1['t'], c=density, cmap=truncated_cmap, s=50)
    axes_max = max(df1['Et'].max()+0.1,df1['t'].max()+0.1)
    x_min, x_max = -0.05, axes_max
    y_min, y_max = -0.05, axes_max
    ax.set_xlim(x_min, x_max)  # 设置X轴的范围
    ax.set_ylim(y_min, y_max)  # 设置Y轴的范围
    ax.set_aspect('equal', adjustable='box')  # 使轴比例一致
    
    # 添加 1:1 线
    ax.plot([x_min, x_max], [y_min, y_max], linestyle='--', color='gray', linewidth=2, label='1:1 line')
    ax.text(x=0.7, y=0.1, s=r'$R=$'+"{:.2f}".format(r2), fontsize=20, transform=ax.transAxes)
    # 添加颜色条
    cbar = fig.colorbar(scatter, ax=ax)
    cbar.set_label('Density')
    
    # 添加标题和轴标签
    ax.set_title(f"{flux_site}")
    ax.set_xlabel("T_SAP(mm)")
    ax.set_ylabel("T_FLUX(mm)")
    ax.legend(frameon=False, fontsize=18, loc = 'lower right')
    # 显示图形
    plt.show()
    fig.savefig('F:/phd1/V6/01allsite/09et_part/'+flux_site+'_ver.jpg',dpi=300, format='jpg', bbox_inches='tight')

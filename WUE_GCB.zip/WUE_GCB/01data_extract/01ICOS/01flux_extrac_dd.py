# -*- coding: utf-8 -*-
"""
Created on Sun Apr 21 20:54:23 2024

@author: LF
"""
'''本程序用于提取ICOS双文件通量站点的日尺度各变量数据。'''
#注意实时更换IGBP

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import glob
import re
import os
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%
def cycle_nan(series):  #去除循环的异常值
    for i in range(len(series)-4):
        if (series[i] == series[i+3]) and (series[i+1] == series[i+4]) and series[i]!=0:            
            series[i] = np.nan   
    return series
def fluxextract(data_df, vari):   #筛选有效的数据    
    try:
        if data_df[vari+'_QC'].isna().all():            
            col = data_df[vari]
        else:
            #根据质量控制QC筛选数据
            data_df.loc[(data_df[vari+'_QC'] > 1) | (data_df[vari+'_QC'] < 0) | (data_df[vari+'_QC'].isna()), vari] = np.nan         
            col = data_df[vari]        
        return col
    except KeyError as e:
        col = pd.Series(np.nan, index=data_df.index)
        print(site, f'站点缺变量{e}')
        return col
#变量代号
vari_list = ['P_F','TA_F', 'SW_IN_F_MDS', 'PA_F', 'SWC_F_MDS_1', 'G_F_MDS', 'VPD_F_MDS', 'WS_F', 'USTAR', 'NETRAD', 'CO2_F_MDS']
#变量简写
variname_list = ['pre', 'ta', 'swin', 'pa', 'swc', 'gf', 'vpd', 'ws', 'ustar', 'rnet', 'co2']
#%%
# 使用pandas读取CSV文件
csvpath1_list = glob.glob(r'F:/phd1/rawdata/ICOS/DBF/FLX_*_FLUXNET2015_FULLSET_*_beta-3/FLX_*_FLUXNET2015_FULLSET_DD_*_beta-3.csv')
for pp in csvpath1_list:
    csv_df1 = pd.read_csv(pp, index_col='TIMESTAMP', parse_dates=True, header=0)   
    pp = pp.replace('\\', '/')
    substrings = re.split(r'/', pp)  # 按/分割
    igbp = substrings[4]
    zipname = substrings[5]
    substrings2 = re.split(r'_', zipname)  # 按/分割
    site0 = substrings2[1]
    site = site0.replace("-", "_")
    csvpath2 = 'F:/phd1/rawdata/ICOS/'+igbp+'/ICOSETC_'+site0+'_ARCHIVE_L2/ICOSETC_'+site0+'_FLUXNET_DD_L2.csv'
    csv_df2 = pd.read_csv(csvpath2, index_col='TIMESTAMP', parse_dates=True, header=0)
    df1_year = csv_df1.index[-1].year
    df2_year = csv_df2.index[0].year
    #拼接两个时段的csv
    if df2_year <= df1_year:
        # 找出 dataframe2 中与 dataframe1 索引重复的行并删除
        csv_df2_duplicates = ~csv_df2.index.isin(csv_df1.index)
        csv_df2_unique = csv_df2[csv_df2_duplicates]
        # 合并 dataframe1 和 dataframe2（去除重复的部分）
        csv_df3 = pd.concat([csv_df1, csv_df2_unique])
        rows, columns = csv_df3.shape
        csv_df4 = csv_df3.copy(deep=True)
        csv_df4 = csv_df4.rename_axis('TIMESTAMP', axis='index')  #重命名索引名称
    elif (df2_year - df1_year) == 1:
        csv_df3 = pd.concat([csv_df1, csv_df2])
        rows, columns = csv_df3.shape
        csv_df4 = csv_df3.copy(deep=True)
        csv_df4 = csv_df4.rename_axis('TIMESTAMP', axis='index')
    else: #若中间有空缺，则用nan补齐
        start_date = csv_df1.index[-1] + timedelta(days=1)
        end_date = csv_df2.index[0] - timedelta(days=1)
        date_range = pd.date_range(start=start_date, end=end_date, freq='D')  # 生成逐日时间戳的日期范围
        df_fill = pd.DataFrame(index=date_range, columns=csv_df1.columns)
        csv_df3 = pd.concat([csv_df1, df_fill, csv_df2])
        rows, columns = csv_df3.shape
        csv_df4 = csv_df3.copy(deep=True)
        csv_df4 = csv_df4.rename_axis('TIMESTAMP', axis='index')
    #筛选有效的数据
    csv_df4.replace(-9999, np.nan, inplace=True)
    datadf = pd.DataFrame(index = csv_df4.index, columns=variname_list)
    for vv in range(len(vari_list)):
        col = fluxextract(csv_df4, vari_list[vv])
        datadf[variname_list[vv]] = col 
    #提取LE    
    le = csv_df4['LE_CORR']
    if le.isna().all():        
        le = csv_df4['LE_F_MDS']
    le = cycle_nan(le)
    le[le < 0] = np.nan
    datadf['le'] = le
    #提取H    
    he = csv_df4['H_CORR']
    if he.isna().all():        
        he = csv_df4['H_F_MDS']
    he = cycle_nan(he)
    he[he < 0] = np.nan
    datadf['he'] = he
    #提取GPP    
    gpp = csv_df4['GPP_NT_VUT_REF']
    gpp = cycle_nan(gpp)
    gpp[gpp < 0] = np.nan
    datadf['gpp'] = gpp
    #提取呼吸    
    reco = csv_df4['RECO_NT_VUT_REF']
    reco = cycle_nan(reco)    
    datadf['reco'] = reco
    
    #提取蒸腾量    
    ta = datadf['ta']    
    le = datadf['le']    
    lamda = (2.501-2.361e-3*ta.values)
    et = le.values*86400*1e-6/lamda  #MJ/m2到mm/d
    et1 = np.where(et < 0, 0, et)
    datadf['et'] = et1    
    #单位换算
    datadf['pa_pa'] = datadf['pa'].values*1000.0    
    datadf['vpd_pa'] = datadf['vpd'].values*100.0        
    try:        
        datadf['swc_m3'] = datadf['swc'].values*0.01        
    except:
        datadf['swc_m3'] = pd.Series(np.nan, index=datadf.index)
    datadf.to_csv('F:/phd1/V6/'+igbp+'/'+site+'/01data_dd/data_ori.csv', float_format='%.4f')



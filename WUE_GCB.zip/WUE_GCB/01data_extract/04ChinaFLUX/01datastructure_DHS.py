# -*- coding: utf-8 -*-
"""
Created on Mon Aug 12 16:33:29 2024

@author: hp
"""
'''构建跟FLUXNet2015类似的数据结构'''
import pandas as pd
import numpy as np
from datetime import datetime
#%%
def deal_excel(excel_df):
    excel_df = excel_df.drop(0, axis=0)  #删除第0行    
    excel_df.rename(columns={'年': 'year', '月': 'month', '日': 'day'}, inplace=True)  # 重命名列
    excel_df.index = pd.to_datetime(excel_df[['year', 'month', 'day']])  #修改index
    excel_df1 = excel_df.drop(['year', 'month', 'day'], axis=1)  #删除列
    return excel_df1
def deal_excel_mm(excel_df):
    excel_df = excel_df.drop(0, axis=0)  #删除第0行    
    excel_df.rename(columns={'年': 'year', '月': 'month'}, inplace=True)  # 重命名列
    excel_df.index = pd.to_datetime(excel_df['year'].astype(str) + '-' + excel_df['month'].astype(str) + '-01')  #修改index
    excel_df1 = excel_df.drop(['year', 'month'], axis=1)  #删除列
    return excel_df1
def deal_excel_yy(excel_df):
    excel_df = excel_df.drop(0, axis=0)  #删除第0行    
    excel_df.rename(columns={'年': 'year'}, inplace=True)  # 重命名列
    excel_df.index = pd.to_datetime(excel_df['year'].astype(str) + '-01-01')  #修改index
    excel_df1 = excel_df.drop(['year'], axis=1)  #删除列
    return excel_df1
def calc_vpd(ta,rh):
    vpd = 0.6108*np.exp((17.27*ta)/(ta+237.3))*(1-rh*0.01)*10
    return vpd
#%%日尺度
start_date = datetime(2003, 1, 1)
end_date = datetime(2010, 12, 31)
date_range = pd.date_range(start=start_date, end=end_date, freq='D')  # 生成逐日时间戳的日期范围
columns_list = ['P_F','TA_F', 'SW_IN_F_MDS', 'PA_F', 'SWC_F_MDS_1', 'VPD_F_MDS', 'WS_F', 'NETRAD', 'LE', 'HE', 'RECO', 'GPP']
df_fill = pd.DataFrame(index=date_range, columns=columns_list)
year_list = list(range(2003,2011))
df_list = []
igbp = 'EBF'
siteid = 'CN_DHS'
for yy in year_list:    
    metepath = 'F:/FLUX/download/ChinaFLUX/鼎湖山/'+str(yy)+'年鼎湖山气象日统计数据.xlsx'       
    mete_df = pd.read_excel(metepath, index_col=False, header=0)
    mete_df1 = deal_excel(mete_df)
    fluxpath = 'F:/FLUX/download/ChinaFLUX/鼎湖山/'+str(yy)+'年鼎湖山通量日统计数据.xlsx'       
    flux_df = pd.read_excel(fluxpath, index_col=False, header=0)
    flux_df1 = deal_excel(flux_df)
    df_cat = pd.concat([mete_df1, flux_df1], axis=1)  #气象与通量拼接   
    df_list.append(df_cat)
df_all = pd.concat(df_list, axis=0) #所有年份拼接
df_all = df_all.astype('float64')
df_all.replace(-99999, np.nan, inplace=True)         
df_fill['P_F'] = df_all['日降水量']
df_fill['TA_F'] = df_all['日平均冠层上方空气温度']
df_fill['SW_IN_F_MDS'] = df_all['日平均太阳辐射']
df_fill['PA_F'] = df_all['大气压']
df_fill['SWC_F_MDS_1'] = df_all['一层土壤体积含水量']*100
df_fill['VPD_F_MDS'] = calc_vpd(np.array(df_all['日平均冠层上方空气温度']), np.array(df_all['日平均冠层上方空气湿度']))  # hPa
df_fill['WS_F'] = df_all['日平均冠层上方风速']
df_fill['NETRAD'] = df_all['日平均净辐射']
df_fill['LE_CORR'] = df_all['LE']*1000000/86400
df_fill['H_CORR'] = df_all['Hs']*1000000/86400
df_fill['RECO'] = df_all['RE']
df_fill['GPP'] = df_all['RE']-df_all['NEE']
df_fill.index.name = 'TIMESTAMP'
df_fill.to_csv('F:/FLUX/download/ChinaFLUX/'+igbp+'/'+siteid+'/CHN_'+siteid+'_DD.csv', float_format='%.4f')
#%%月尺度
start_date = datetime(2003, 1, 1)
end_date = datetime(2010, 12, 31)
date_range = pd.date_range(start=start_date, end=end_date, freq='MS')  # 生成逐日时间戳的日期范围
columns_list = ['P_F','TA_F', 'SW_IN_F_MDS', 'PA_F', 'SWC_F_MDS_1', 'VPD_F_MDS', 'WS_F', 'NETRAD', 'LE_CORR', 'H_CORR', 'RECO', 'GPP']
df_fill = pd.DataFrame(index=date_range, columns=columns_list)
year_list = list(range(2003,2011))
df_list = []
igbp = 'EBF'
siteid = 'CN_DHS'
for yy in year_list:    
    metepath = 'F:/FLUX/download/ChinaFLUX/鼎湖山/'+str(yy)+'年鼎湖山气象月统计数据.xlsx'       
    mete_df = pd.read_excel(metepath, index_col=False, header=0)
    mete_df1 = deal_excel_mm(mete_df)
    fluxpath = 'F:/FLUX/download/ChinaFLUX/鼎湖山/'+str(yy)+'年鼎湖山通量月统计数据.xlsx'       
    flux_df = pd.read_excel(fluxpath, index_col=False, header=0)
    flux_df1 = deal_excel_mm(flux_df)
    df_cat = pd.concat([mete_df1, flux_df1], axis=1)  #气象与通量拼接   
    df_list.append(df_cat)
df_all = pd.concat(df_list, axis=0) #所有年份拼接
df_all = df_all.astype('float64')
df_all.replace(-99999, np.nan, inplace=True)       
df_fill['P_F'] = df_all['月降水量']
df_fill['TA_F'] = df_all['月平均冠层上方空气温度']
df_fill['SW_IN_F_MDS'] = df_all['月平均太阳辐射']
df_fill['PA_F'] = df_all['大气压']
df_fill['SWC_F_MDS_1'] = df_all['一层土壤体积含水量']*100
df_fill['VPD_F_MDS'] = calc_vpd(np.array(df_all['月平均冠层上方空气温度']), np.array(df_all['月平均冠层上方空气湿度']))  # hPa
df_fill['WS_F'] = df_all['月平均冠层上方风速']
df_fill['NETRAD'] = df_all['月平均净辐射']
df_fill['LE_CORR'] = df_all['LE']*1000000/86400
df_fill['H_CORR'] = df_all['Hs']*1000000/86400
df_fill['RECO'] = df_all['RE']
df_fill['GPP'] = df_all['RE']-df_all['NEE']
df_fill.index.name = 'TIMESTAMP'
df_fill.to_csv('F:/FLUX/download/ChinaFLUX/'+igbp+'/'+siteid+'/CHN_'+siteid+'_MM.csv', float_format='%.4f')
#%%年尺度
start_date = datetime(2003, 1, 1)
end_date = datetime(2010, 12, 31)
date_range = pd.date_range(start=start_date, end=end_date, freq='AS')  # 生成逐日时间戳的日期范围
columns_list = ['P_F','TA_F', 'SW_IN_F_MDS', 'PA_F', 'SWC_F_MDS_1', 'VPD_F_MDS', 'WS_F', 'NETRAD', 'LE_CORR', 'H_CORR', 'RECO', 'GPP']
df_fill = pd.DataFrame(index=date_range, columns=columns_list)
year_list = list(range(2003,2011))
df_list = []
igbp = 'EBF'
siteid = 'CN_DHS'
for yy in year_list:    
    metepath = 'F:/FLUX/download/ChinaFLUX/鼎湖山/'+str(yy)+'年鼎湖山气象年统计数据.xlsx'       
    mete_df = pd.read_excel(metepath, index_col=False, header=0)
    mete_df1 = deal_excel_yy(mete_df)
    fluxpath = 'F:/FLUX/download/ChinaFLUX/鼎湖山/'+str(yy)+'年鼎湖山通量年统计数据.xlsx'       
    flux_df = pd.read_excel(fluxpath, index_col=False, header=0)
    flux_df1 = deal_excel_yy(flux_df)
    df_cat = pd.concat([mete_df1, flux_df1], axis=1)  #气象与通量拼接   
    df_list.append(df_cat)
df_all = pd.concat(df_list, axis=0) #所有年份拼接
df_all = df_all.astype('float64')
df_all.replace(-99999, np.nan, inplace=True)       
df_fill['P_F'] = df_all['年降水量']
df_fill['TA_F'] = df_all['年平均冠层上方空气温度']
df_fill['SW_IN_F_MDS'] = df_all['年平均太阳辐射']
df_fill['PA_F'] = df_all['大气压']
df_fill['SWC_F_MDS_1'] = df_all['一层土壤体积含水量']*100
df_fill['VPD_F_MDS'] = calc_vpd(np.array(df_all['年平均冠层上方空气温度']), np.array(df_all['年平均冠层上方空气湿度']))  # hPa
df_fill['WS_F'] = df_all['年平均冠层上方风速']
df_fill['NETRAD'] = df_all['年平均净辐射']
df_fill['LE_CORR'] = df_all['LE']*1000000/86400
df_fill['H_CORR'] = df_all['Hs']*1000000/86400
df_fill['RECO'] = df_all['RE']
df_fill['GPP'] = df_all['RE']-df_all['NEE']
df_fill.index.name = 'TIMESTAMP'
df_fill.to_csv('F:/FLUX/download/ChinaFLUX/'+igbp+'/'+siteid+'/CHN_'+siteid+'_YY.csv', float_format='%.4f')
#%%

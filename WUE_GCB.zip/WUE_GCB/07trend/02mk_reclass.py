# -*- coding: utf-8 -*-
"""
Created on Mon May 20 14:36:14 2024

@author: LF
"""
'''本程序用于对各站点趋势数据进行重分类。'''
#无需更换IGBP
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import glob
import os
import re
#%%
def reclass(lonlat, sen_df, siteid, colname):
    if (sen_df.iloc[0,0] == 'increasing') & (sen_df.iloc[0,1] == 'increasing'):
        lonlat.loc[lonlat['siteid'] == siteid, colname] = 1
    elif (sen_df.iloc[0,0] == 'increasing') & (sen_df.iloc[0,1] == 'no trend'):
        lonlat.loc[lonlat['siteid'] == siteid, colname] = 2
    elif (sen_df.iloc[0,0] == 'increasing') & (sen_df.iloc[0,1] == 'decreasing'):
        lonlat.loc[lonlat['siteid'] == siteid, colname] = 3
    elif (sen_df.iloc[0,0] == 'no trend') & (sen_df.iloc[0,1] == 'increasing'):
        lonlat.loc[lonlat['siteid'] == siteid, colname] = 4
    elif (sen_df.iloc[0,0] == 'no trend') & (sen_df.iloc[0,1] == 'no trend'):
        lonlat.loc[lonlat['siteid'] == siteid, colname] = 5
    elif (sen_df.iloc[0,0] == 'no trend') & (sen_df.iloc[0,1] == 'decreasing'):
        lonlat.loc[lonlat['siteid'] == siteid, colname] = 6
    elif (sen_df.iloc[0,0] == 'decreasing') & (sen_df.iloc[0,1] == 'increasing'):
        lonlat.loc[lonlat['siteid'] == siteid, colname] = 7
    elif (sen_df.iloc[0,0] == 'decreasing') & (sen_df.iloc[0,1] == 'no trend'):
        lonlat.loc[lonlat['siteid'] == siteid, colname] = 8
    elif (sen_df.iloc[0,0] == 'decreasing') & (sen_df.iloc[0,1] == 'decreasing'):
        lonlat.loc[lonlat['siteid'] == siteid, colname] = 9
    else:
        print(siteid+'输入有误！')
    return lonlat
#%%
info_path = 'F:/phd1/V10/01allsite/01siteinfo/siteinfo_dem.csv'
site_frame = pd.read_csv(info_path, index_col=0, header=0)
dir_list = glob.glob(r'F:/phd1/V10/*/*/07trend/wue_sen.xlsx')
for dd in dir_list:
    dd = dd.replace('\\', '/')
    substrings = re.split(r'/', dd)  # 按/分割
    igbp = substrings[3]
    siteid = substrings[4]
    csvpath2 = 'F:/phd1/V10/'+igbp+'/'+siteid+'/07trend/di_sen.xlsx'
    wuesen = pd.read_excel(dd, index_col=0, parse_dates=True, header=0)[['TWUE', 'IWUE']]  #读入WUE、iWUE趋势数据
    disen = pd.read_excel(csvpath2, index_col=0, parse_dates=True, header=0)  #读入WUE、iWUE趋势数据    
    lonlat1 = reclass(site_frame, disen, siteid, 'di_trend')
    lonlat2 = reclass(lonlat1, wuesen, siteid, 'wue_trend')
    print(siteid)
lonlat2.dropna().to_excel('F:/phd1/V10/01allsite/03trend/lonlat_sen.xlsx', index=True, header=True, float_format='%.2f')



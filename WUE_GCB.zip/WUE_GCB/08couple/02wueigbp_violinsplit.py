# -*- coding: utf-8 -*-
"""
Created on Wed Sep 25 16:02:35 2024

@author: LF
"""
'''根据分组的偏相关系数绘制小提琴图。'''
############分igbp站点需手动修改
import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import pandas as pd
import numpy as np
import re
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%
def fig_violin(path1, path2, df1_name, df2_name, ymin, ymax):  #准备小提琴图数据  
    pcor1 = pd.read_csv(path1, index_col=0, header=0).abs()
    pcor2 = pd.read_csv(path2, index_col=0, header=0).abs()
    # 合并为长格式
    df_melted = pd.concat([
        pcor1.melt(var_name='Group', value_name='Value').assign(Source=df1_name),
        pcor2.melt(var_name='Group', value_name='Value').assign(Source=df2_name)
    ])
    melted_couple = df_melted.dropna(subset=['Value']).reset_index(drop=True) #删除nan值
    # 绘图
    parameters = {'axes.labelsize': 20,
              'axes.titlesize': 25,
              'xtick.labelsize': 20,
              'ytick.labelsize': 20,
              'figure.dpi': 300,
              'lines.linewidth': 3,
              'font.family': 'Arial',
              'axes.titlepad': 20}
    plt.rcParams.update(parameters)
    new_labels = ['P1', 'P2', 'P3', 'P4', 'P5', 'P6', 'P7', 'P8']  # 自定义刻度标签
    fig, ax = plt.subplots(1, 1, figsize=(9, 6))
    sns.violinplot(
        x="Group", 
        y="Value", 
        hue="Source", 
        data=melted_couple,
        ax=ax,
        split=True,
        palette={df1_name: '#8fc3e8', df2_name: '#ffc07d'},
        inner=None,
        linewidth=1.5
    )
    box_palette = {df1_name: '#1f77b4', df2_name: '#ff7f0e'}     # 深色
    # 叠加半透明箱线图
    sns.boxplot(
        x="Group", 
        y="Value", 
        hue="Source", 
        data=melted_couple, 
        width=0.2,
        whis=0,           # 关键参数：须线范围设为0（即不显示）
        showfliers=False,  # 同时隐藏异常点
        showcaps=False,
        ax=ax,
        palette=box_palette,  # 箱体深色
        patch_artist=True,  # 启用独立填充和边框
        boxprops={
            #"facecolor": [box_palette[s] for s in df_melted['Source'].unique()],  # 填充色
            "edgecolor": "black", # 边框色（透明）
            "linewidth": 1,
        },
        medianprops={
            "color": "white",    # 中位数线颜色
            "linewidth": 2,
        },
        legend=False
        )
    ax.set_xticklabels(new_labels)
    ax.set_ylim(ymin, ymax)
    ax.yaxis.set_major_locator(ticker.MultipleLocator(0.2))  #显示1位刻度标签
    # 美化图形
    var1 = re.split(r'_', df1_name)[0]
    var2 = re.split(r'_', df1_name)[1]
    var3 = re.split(r'_', df2_name)[1]
    plt.title(f'|pcor({var1}, {var2}&{var3})|')
    plt.xlabel('Drought Phases', labelpad = 20)
    plt.ylabel('', labelpad = 20, fontsize = 25)
    plt.legend(ncol=1, bbox_to_anchor=(0.95, 0.15), frameon=False, fontsize=18, bbox_transform=fig.transFigure)
    plt.tight_layout()
    plt.show()
    return melted_couple, fig
#%%
csvpath1 = 'F:/phd1/V10/01allsite/06couple/gpp-EWUE.csv'
csvpath2 = 'F:/phd1/V10/01allsite/06couple/et-EWUE.csv'
csvpath3 = 'F:/phd1/V10/01allsite/06couple/gpp-TWUE.csv'
csvpath4 = 'F:/phd1/V10/01allsite/06couple/t-TWUE.csv'
csvpath5 = 'F:/phd1/V10/01allsite/06couple/gpp-IWUE.csv'
csvpath6 = 'F:/phd1/V10/01allsite/06couple/gc-IWUE.csv'
csvpath7 = 'F:/phd1/V10/01allsite/06couple/gc-gpp.csv'
csvpath8 = 'F:/phd1/V10/01allsite/06couple/gc-t.csv'
csvpath9 = 'F:/phd1/V10/01allsite/06couple/t-gpp.csv'
csvpath10 = 'F:/phd1/V10/01allsite/06couple/et-gpp.csv'
ewue, fig_ewue = fig_violin(csvpath1, csvpath2, 'EWUE_GPP', 'EWUE_ET', 0.6, 0.9)
twue, fig_twue = fig_violin(csvpath3, csvpath4, 'TWUE_GPP', 'TWUE_T', 0.4, 0.9)
iwue, fig_iwue = fig_violin(csvpath5, csvpath6, 'IWUE_GPP', 'IWUE_Gc', 0.3, 0.8)
tg, fig_tg = fig_violin(csvpath7, csvpath8, 'Gc_GPP', 'Gc_T', 0, 1)
eg, fig_eg = fig_violin(csvpath9, csvpath10, 'GPP_T', 'GPP_ET', 0.2, 1)
fig_ewue.savefig('F:/phd1/V10/01allsite/06couple/EWUE_violin_half.jpg',dpi=300, format='jpg', bbox_inches='tight')
fig_twue.savefig('F:/phd1/V10/01allsite/06couple/TWUE_violin_half.jpg',dpi=300, format='jpg', bbox_inches='tight')
fig_iwue.savefig('F:/phd1/V10/01allsite/06couple/IWUE_violin_half.jpg',dpi=300, format='jpg', bbox_inches='tight')
fig_tg.savefig('F:/phd1/V10/01allsite/06couple/TG_violin_half.jpg',dpi=300, format='jpg', bbox_inches='tight')
fig_eg.savefig('F:/phd1/V10/01allsite/06couple/EG_violin_half.jpg',dpi=300, format='jpg', bbox_inches='tight')

#%%


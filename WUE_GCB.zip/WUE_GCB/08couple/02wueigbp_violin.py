# -*- coding: utf-8 -*-
"""
Created on Wed Sep 25 16:02:35 2024

@author: LF
"""
'''根据分组的偏相关系数绘制小提琴图。'''
############分igbp站点需手动修改
import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%
def data_violin(path):  #准备小提琴图数据  
    pcor = pd.read_csv(path, index_col=0, parse_dates=True, header=0).abs()
    group_unique_values = [int(item) for item in list(pcor.columns)]  # 确保按顺序取出唯一组别
    tab10 = plt.get_cmap('tab10')# 获取tab10调色板
    value_to_color_index = {
        1: 0,  # tab10的第0个颜色 (索引从0开始，所以2是第3个)
        2: 4,  # tab10的第4个颜色
        3: 2,  # tab10的第2个颜色
        4: 1,  # tab10的第1个颜色
        5: 3,  # tab10的第3个颜色
        6: 5,  # tab10的第5个颜色
        7: 8,  # tab10的第8个颜色
        8: 6,  # tab10的第6个颜色    
    }
    colors = [tab10(value_to_color_index[val]) for val in group_unique_values]
    melted_couple = pcor.melt(var_name='group', value_name='pcor', ignore_index = True) #短数据变长数据
    couple2 = melted_couple.dropna(subset=['pcor']).reset_index(drop=True) #删除nan值
    return couple2, colors
#%%
csvpath1 = 'F:/phd1/V10/DBF/01multisite/03couple/gpp-EWUE.csv'
csvpath2 = 'F:/phd1/V10/DBF/01multisite/03couple/et-EWUE.csv'
csvpath3 = 'F:/phd1/V10/DBF/01multisite/03couple/gpp-TWUE.csv'
csvpath4 = 'F:/phd1/V10/DBF/01multisite/03couple/t-TWUE.csv'
csvpath5 = 'F:/phd1/V10/DBF/01multisite/03couple/gpp-IWUE.csv'
csvpath6 = 'F:/phd1/V10/DBF/01multisite/03couple/gc-IWUE.csv'
ewue_gpp, colors1 = data_violin(csvpath1)
ewue_et, colors2 = data_violin(csvpath2)
twue_gpp, colors3 = data_violin(csvpath3)
twue_t, colors4 = data_violin(csvpath4)
iwue_gpp, colors5 = data_violin(csvpath5)
iwue_gc, colors6 = data_violin(csvpath6)

parameters = {'axes.labelsize': 40,
          'axes.titlesize': 45,
          'xtick.labelsize': 35,
          'ytick.labelsize': 35,
          'figure.dpi': 300,
          'lines.linewidth': 3,
          'font.family': 'Arial',
          'axes.titlepad': 20}
plt.rcParams.update(parameters)
fig, axes = plt.subplots(3, 2, figsize=(18, 21))
new_labels = ['P1', 'P2', 'P3', 'P4', 'P5', 'P6', 'P7', 'P8']  # 自定义刻度标签
sns.violinplot(x='group', y='pcor', data=ewue_gpp, ax=axes[0,0], palette=colors1)  # 在指定的axes对象ax上绘制小提琴图
axes[0,0].set_ylim(0, 1)
axes[0,0].set_title('|pcor(EWUE,GPP)|')
axes[0,0].set_xlabel('')
axes[0,0].set_ylabel('', fontsize=45, labelpad = 20)
axes[0,0].set_xticklabels([])
axes[0,0].yaxis.set_major_locator(ticker.MultipleLocator(0.2))  #显示1位刻度标签
sns.violinplot(x='group', y='pcor', data=ewue_et, ax=axes[0,1], palette=colors2)  # 在指定的axes对象ax上绘制小提琴图
axes[0,1].set_ylim(0, 1)
axes[0,1].set_title('|pcor(EWUE,ET)|')
axes[0,1].set_xlabel('')
axes[0,1].set_ylabel('')
axes[0,1].set_xticklabels([])
axes[0,1].set_yticklabels([])
axes[0,1].yaxis.set_major_locator(ticker.MultipleLocator(0.2))  #显示1位刻度标签
sns.violinplot(x='group', y='pcor', data=twue_gpp, ax=axes[1,0], palette=colors3)  # 在指定的axes对象ax上绘制小提琴图
axes[1,0].set_ylim(0, 1)
axes[1,0].set_title('|pcor(TWUE,GPP)|')
axes[1,0].set_xlabel('')
axes[1,0].set_ylabel('', fontsize=45, labelpad = 20)
axes[1,0].set_xticklabels([])
axes[1,0].yaxis.set_major_locator(ticker.MultipleLocator(0.2))  #显示1位刻度标签
sns.violinplot(x='group', y='pcor', data=twue_t, ax=axes[1,1], palette=colors4)  # 在指定的axes对象ax上绘制小提琴图
axes[1,1].set_ylim(0, 1)
axes[1,1].set_title('|pcor(TWUE,T)|')
axes[1,1].set_xlabel('')
axes[1,1].set_ylabel('')
axes[1,1].set_xticklabels([])
axes[1,1].set_yticklabels([])
axes[1,1].yaxis.set_major_locator(ticker.MultipleLocator(0.2))  #显示1位刻度标签
sns.violinplot(x='group', y='pcor', data=iwue_gpp, ax=axes[2,0], palette=colors5)  # 在指定的axes对象ax上绘制小提琴图
axes[2,0].set_ylim(0, 1)
axes[2,0].set_title('|pcor(IWUE,GPP)|')
axes[2,0].set_ylabel('', fontsize=45, labelpad = 20)
axes[2,0].set_xlabel('Drought Phases', fontsize=40)
axes[2,0].set_xticklabels(new_labels)
axes[2,0].yaxis.set_major_locator(ticker.MultipleLocator(0.2))  #显示1位刻度标签
sns.violinplot(x='group', y='pcor', data=iwue_gc, ax=axes[2,1], palette=colors6)  # 在指定的axes对象ax上绘制小提琴图
axes[2,1].set_ylim(0, 1)
axes[2,1].set_title('|pcor(IWUE,Gc)|')
axes[2,1].set_xticklabels(new_labels)# 设置新的刻度标签
axes[2,1].set_yticklabels([])
axes[2,1].set_ylabel('')
axes[2,1].set_xlabel('Drought Phases', fontsize=40)
axes[2,1].yaxis.set_major_locator(ticker.MultipleLocator(0.2))  #显示1位刻度标签
plt.tight_layout()
plt.show()
fig.savefig('F:/phd1/V10/DBF/01multisite/03couple/DBF_WUE_violin.jpg',dpi=300, format='jpg', bbox_inches='tight')

